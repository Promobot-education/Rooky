#!/usr/bin/env python
# -*- coding: utf-8 -*-

import socket
import collections

import rospy
import diagnostic_updater as DIAG

from std_msgs.msg import Bool, UInt8
from promobot_msgs.msg import ServoStates, ScriptProcess
from promobot_srvs.srv import Bool as SrvBool


#############################################################
#############################################################
class ServoMonitoring():
#############################################################
#############################################################

    #############################################################
    def __init__(self):
    #############################################################
        rospy.init_node("servo_monitoring")
        self.nodename = rospy.get_name()
        rospy.loginfo("%s starting" % self.nodename)

        self.updater = DIAG.Updater()
        self.updater.setHardwareID(socket.gethostname())
        self.updater.add('Servos calibration', self.servos_calibrated)
        self.updater.add('Servos state', self.servos_state)

        self.servos                 = ServoStates()
        self.servos_prev            = ServoStates()
        self.left_arm_error         = False
        self.right_arm_error        = False
        self.head_error             = False
        self.torso_error            = False

        self.reset_logging          = True
        self.left_arm_logged        = False
        self.right_arm_logged       = False
        self.head_logged            = False
        self.torso_logged           = False

        self.is_calibrated          = None
        self.is_script              = False
        self.msgs_queue             = {}
        self.calibration_step       = 0

        self.motor_issue_logging        = {}
        self.motor_not_moving_logging   = {}

        self.max_calibration_count  = rospy.get_param('/torque_control/maxCalibrationCount', 3)

        rospy.Subscriber('promobot_servos/calibration_step',
                         UInt8, self.calibrationStepCallback)

        rospy.wait_for_service('/parameter_server/is_started')
        rospy.wait_for_service('/promobot_servos/is_calibrated')

        try:
            self.is_parameter_srv = rospy.ServiceProxy('/parameter_server/is_started', SrvBool)
            self.is_calibrated_srv = rospy.ServiceProxy('/promobot_servos/is_calibrated', SrvBool)
        except rospy.ServiceException as e:
            rospy.logerr("Service call failed: %s", e)

        is_parameter_started = False
        while not is_parameter_started:
            try:
                parameter_started_resp  = self.is_parameter_srv()
                is_parameter_started    = parameter_started_resp.ok
            except rospy.ServiceException as e:
                rospy.logerr("Service call failed: %s", e)
            if not is_parameter_started:
                rospy.sleep(1)


        self.motor_issue_delta_pos  = rospy.get_param('/servo_monitoring/motor_issue_delta_pos', 150)
        self.motor_issue_duration   = rospy.get_param('/servo_monitoring/motor_issue_duration', 1.0)
        self.as5047_issue_delta_pos = rospy.get_param('/servo_monitoring/as5047_issue_delta_pos', 1000)
        self.max_duration           = rospy.get_param('/servo_monitoring/max_collecting_duration', 5.0)

        self.rate = rospy.get_param("~rate", 10)
        self.timeout = rospy.get_param("~timeout", 5)
        self.timeout_ticks = rospy.get_param("~timeout_ticks", self.rate * self.timeout)

        rospy.Subscriber('/promobot_servos/core', ServoStates, self.servosCallback)
        rospy.Subscriber('/script/process', ScriptProcess, self.scriptCallback)
        rospy.loginfo("%s started successful" % self.nodename)

    #############################################################
    def servos_calibrated(self, stat):
    #############################################################
        if self.is_calibrated:
            stat.summary(DIAG.OK, 'OK')
        else:
            stat.summary(DIAG.WARN, 'Not calibrated')
        stat.add("Calibration step", self.calibration_step)
        return stat

    #############################################################
    def servos_state(self, stat):
    #############################################################
        stat.summary(DIAG.OK, "OK")
        for idx, servo in enumerate(self.servos.states):
            ok = True

            if servo.fault_code:
                stat.mergeSummary(DIAG.ERROR, "Fault on %d" % servo.id)
                stat.add("Servo %d" % servo.id, servo.fault_code_str)
                ok = False

            if servo.id != 36 and servo.id != 26 and servo.torque \
                    and abs(servo.position - servo.setPoint) > self.as5047_issue_delta_pos:
                stat.mergeSummary(DIAG.ERROR, "Stucked on %d" % servo.id)
                stat.add("Servo %d" % servo.id, "Stucked: %i -> %s" % (servo.position, servo.setPoint))
                ok = False

            if (self.calibration_step == 0 or self.calibration_step == 4) \
                    and servo.id != 36 and servo.id != 26 \
                    and abs(servo.position - self.servos_prev.states[idx].position) > self.as5047_issue_delta_pos:
                stat.mergeSummary(DIAG.ERROR, "as5747 on %d" % servo.id)
                stat.add("Servo %d" % servo.id, "as5747 issue. New: %s\nOld: %s" % (servo, self.servos_prev.states[idx]))
                ok = False

            if ok:
                stat.add("Servo %d" % servo.id, "OK")

        if not any(self.servos.states):
            stat.mergeSummary(DIAG.ERROR, "No new data from servos")
        return stat

    #############################################################
    def spin(self):
    #############################################################
        r = rospy.Rate(self.rate)
        self.ticks_since_target = self.timeout_ticks

        ###### main loop ######
        while not rospy.is_shutdown():
            self.spinOnce()
            self.updater.update()
            r.sleep()

    #############################################################
    def spinOnce(self):
    #############################################################
        is_calibrated = False
        try:
            resp            = self.is_calibrated_srv()
            is_calibrated   = resp.ok
        except rospy.ServiceException as e:
            # rospy.logerr("Service call failed: %s", e)
            pass
        if is_calibrated != self.is_calibrated:
            self.is_calibrated = is_calibrated
            rospy.loginfo("serovos calibrated %s", self.is_calibrated)

    #############################################################
    def servosCallback(self,msg):
    #############################################################
        self.servos_prev = self.servos
        self.servos = msg
        self.msgs_queue[rospy.Time.now().to_sec()] = self.servos

        if self.servos_prev != ServoStates():
            for key in self.msgs_queue.keys():
                if key < rospy.Time.now().to_sec() - self.max_duration:
                    self.msgs_queue.pop(key)

            i = 0
            for servo in self.servos.states: # motor issue
                if self.reset_logging:
                    self.motor_issue_logging[servo.id]      = False
                    self.motor_not_moving_logging[servo.id] = False
                    self.reset_logging = False
                if ((servo.fault_code & 0x08) >> 2) > 0:
                    if servo.id in self.motor_issue_logging and not self.motor_issue_logging[servo.id]:
                        is_moving = self.checkMoving(servo.id, self.motor_issue_duration, self.motor_issue_delta_pos)
                        self.motor_issue_logging[servo.id] = True
                        if is_moving:
                            rospy.loginfo("motor overcurrent id: %i, current %0.3fA, is_moving: %s, moving_duration: %0.3fs" % (servo.id, servo.motorCurrent/1000.0, is_moving, self.getMovementDuration(servo.id, self.motor_issue_duration, self.motor_issue_delta_pos) ))
                        else:
                            rospy.loginfo("motor overcurrent id: %i, current %0.3fA, is_moving: %s" % (servo.id, servo.motorCurrent/1000.0, is_moving))
                else:
                    self.motor_issue_logging[servo.id] = False

                if servo.id != 36 and servo.id != 26 and servo.torque:
                    if abs(servo.position - servo.setPoint) > self.as5047_issue_delta_pos:
                        if servo.id in self.motor_not_moving_logging and not self.motor_not_moving_logging[servo.id]:
                            self.motor_not_moving_logging[servo.id] = True
                            rospy.loginfo("motor issue. maybe motor stucked id: %i, position %i, setPoint: %s" % (servo.id, servo.position, servo.setPoint))
                    else:
                        self.motor_not_moving_logging[servo.id] = False

                if (self.calibration_step == 0 or self.calibration_step == 4) and servo.id != 36 and servo.id != 26 and abs(servo.position - self.servos_prev.states[i].position) > self.as5047_issue_delta_pos:
                    rospy.loginfo("as5747 issue on servo %i\n\nnew info:\n%s\n\nold info:\n%s\n" % (servo.id,servo, self.servos_prev.states[i]))
                i = i + 1

    #############################################################
    def checkMoving(self, id, duration, delta):
    #############################################################
        positions = []
        for key in self.msgs_queue.keys():
            if key > rospy.Time.now().to_sec() - duration:
                positions.append([x.position for x in self.msgs_queue[key].states
                                  if x.id == id][0])
        if abs(min(positions) - max(positions)) > delta:
            return True
        else:
            return False
    #############################################################

    #############################################################
    def getMovementDuration(self, id, duration, delta):
    #############################################################
        od = collections.OrderedDict(sorted(self.msgs_queue.items()))
        movement_start = movement_end = od.keys()[-1]
        velocity_cur = 0
        velocity_prev = 0
        for key in reversed(od.keys()):
            # print key,[x.velocity for x in od[key].states if x.id == id][0]
            if velocity_cur == 0 and velocity_prev != 0:
                movement_start = key
            velocity_prev = velocity_cur
            velocity_cur = [x.velocity for x in od[key].states
                            if x.id == id][0]
        return movement_end - movement_start
    #############################################################

    #############################################################
    def scriptCallback(self, msg):
    #############################################################
        self.is_script = msg.process

    #############################################################

    #############################################################
    def calibrationStepCallback(self, msg):
    #############################################################
        self.calibration_step = msg.data
        rospy.loginfo("calibration_step: %i" % self.calibration_step)

    #############################################################


#############################################################
#############################################################
if __name__ == '__main__':
    """ main """
    try:
        servoMonitiong = ServoMonitoring()
        servoMonitiong.spin()
    except rospy.ROSInterruptException:
        pass

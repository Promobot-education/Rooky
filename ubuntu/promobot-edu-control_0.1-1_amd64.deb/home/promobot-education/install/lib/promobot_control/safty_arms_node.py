#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import roslib
from std_msgs.msg import *
from promobot_msgs.msg import *
from promobot_srvs.srv import *
import collections
import numpy
import math
import subprocess
import threading
import rosparam
import rospkg
import os
#############################################################
#############################################################

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class ServoMonitoring():
#############################################################
#############################################################

    #############################################################
    def __init__(self):
    #############################################################
        rospy.init_node("servo_monitoring")
        self.nodename = rospy.get_name()
        rospy.loginfo("%s starting" % self.nodename)

        self.servos                 = ServoStates()
        self.servos_prev            = ServoStates()

        self.is_scripts_calibrating         = False
        self.is_calibrated          = True
        self.is_script              = False
        self.is_script_prev         = False
        self.script_calibrated      = False
        self.use_safety_arms        = True

        self.left_arm_canceled      = False
        self.right_arm_canceled     = False
        self.is_debug = False
        self.can_run_script = True

        self.servos_avg_calibration     = {}
        self.servos_avg_calibration_vel = {}
        self.servos_max_diff            = {}
        self.servos_s_calibration       = {}
        self.servos_calibration         = {}
        self.servos_calibration_vel     = {}
        self.servos_calibration_data    = {}
        self.servos_calibration_data_vel    = {}
        self.calibration_step           = 0

        self.count = 0
        self.max_error = 0
        self.script_calibration_count = 0

        self.max_calibraion_count = 10
        self.all_calibrations = []
        self.min_vel = 100
        self.max_cur = 200
        self.max_pogr = 0.25

        self.have_error = False
        self.left_arm_error     = False
        self.right_arm_error    = False
        self.statistics         = {}

        self.pub_test_calib     = {}
        self.pub_test_pos       = {}
        self.pub_test_cur       = {}
        self.pub_test_vel       = {}
        self.pub_test_s         = {}
        self.pub_test_max_diff  = {}
        self.pub_test_cur_arr   = {}
        self.motor_cur_arr      = {}
        self.motor_cur_arr_size = 1

        self.wait_for_start = True

        self.full_calibration = False
        self.check_calibration = False
        self.all_scripts_runs = 0
        self.failure_scripts_runs = 0
        self.cur_script_name = ''
        self.prev_script_name = ''
        self.cur_voltage = 1.0

        self.last_recieved_msg_time = rospy.get_time()

        self.servos_all_calibration = []
        self.servos_all_calibration_vel = []

        self.joints = ['right_arm_1_joint', 'right_arm_2_joint', 'right_arm_3_joint', 'right_arm_4_joint', 'right_arm_5_joint', 'left_arm_1_joint', 'left_arm_2_joint', 'left_arm_3_joint', 'left_arm_4_joint', 'left_arm_5_joint']

        for joint in self.joints:
            self.motor_cur_arr[joint] = [0] * self.motor_cur_arr_size
            self.servos_calibration[joint] = []
            self.servos_calibration_vel[joint] = []
            self.servos_calibration_data[joint] = []
            self.servos_calibration_data_vel[joint] = []
            self.servos_avg_calibration[joint] = []
            self.servos_avg_calibration_vel[joint] = []
            self.servos_max_diff[joint] = []
            self.servos_s_calibration[joint] = []

            if self.is_debug:
                self.pub_test_calib[joint] = rospy.Publisher('/test/' + joint + '/calib', std_msgs.msg.Int16, queue_size=5)
                self.pub_test_pos[joint] = rospy.Publisher('/test/' + joint + '/pos', std_msgs.msg.Int16, queue_size=5)
                self.pub_test_cur[joint] = rospy.Publisher('/test/' + joint + '/cur', std_msgs.msg.Int16, queue_size=5)
                self.pub_test_vel[joint] = rospy.Publisher('/test/' + joint + '/vel', std_msgs.msg.Int16, queue_size=5)
                self.pub_test_s[joint] = rospy.Publisher('/test/' + joint + '/s', std_msgs.msg.Float32, queue_size=5)
                self.pub_test_max_diff[joint] = rospy.Publisher('/test/' + joint + '/max_diff', std_msgs.msg.Float32, queue_size=5)
                self.pub_test_cur_arr[joint] = rospy.Publisher('/test/' + joint + '/cur_arr', std_msgs.msg.Int16MultiArray, queue_size=5)

        rospy.Subscriber('promobot_servos/calibration_step', std_msgs.msg.UInt8, self.calibrationStepCallback)
        rospy.Subscriber('scripts_calibration/start', std_msgs.msg.Bool, self.calibrationStart)
        self.pub_enable_right_arm = rospy.Publisher('/promobot_servos/scripts/enable/right_arm', std_msgs.msg.Empty, queue_size=5)
        self.pub_enable_left_arm = rospy.Publisher('/promobot_servos/scripts/enable/left_arm', std_msgs.msg.Empty, queue_size=5)

        rospy.wait_for_service('/parameter_server/is_started')
        rospy.wait_for_service('/script/start')
#        rospy.wait_for_service('/promobot_servos/is_calibrated')

        try:
            self.is_parameter_srv   = rospy.ServiceProxy('/parameter_server/is_started', Bool)
            self.is_calibrated_srv  = rospy.ServiceProxy('/promobot_servos/is_calibrated', Bool)
            self.script_srv  = rospy.ServiceProxy('/script/start', Script)
        except rospy.ServiceException, e:
            rospy.logerr("Service call failed: %s"%e)

        is_parameter_started = False
        while is_parameter_started == False:
            try:
                parameter_started_resp  = self.is_parameter_srv()
                is_parameter_started    = parameter_started_resp.ok
                if not is_parameter_started:
                    rospy.sleep(1)
            except rospy.ServiceException, e:
                rospy.logerr("Service call failed: %s"%e)

        self.rate = rospy.get_param("~rate", 10)
        self.timeout = rospy.get_param("~timeout", 5)
        self.timeout_ticks = rospy.get_param("~timeout_ticks", self.rate * self.timeout)

        self.safty_scripts = []
        self.safty_scripts = rospy.get_param('scripts_calibration/safty_scripts', [])
        for script in self.safty_scripts:
            self.statistics[script] = {'all_runs': 0, 'failure': 0}

        rospy.Subscriber('/promobot_servos/core', ServoStates, self.servosCallback)
        rospy.Subscriber('/script/process', ScriptProcess, self.scriptCallback)
        rospy.Subscriber('/power_board/voltages', PowerValueArray, self.powerBoardVoltages)
        rospy.Subscriber('/scripts_calibration/start_calibrate', std_msgs.msg.Empty, self.startCalibrateCallback)        
        rospy.Subscriber('/scripts_calibration/check_scripts', std_msgs.msg.Bool, self.checkScriptsCallback)

        self.loadParams()
        rospy.loginfo("%s started successful" % self.nodename)

    #############################################################
    def spin(self):
    #############################################################
        r = rospy.Rate(self.rate)
        self.ticks_since_target = self.timeout_ticks

        ###### main loop  ######
        while not rospy.is_shutdown():
            self.spinOnce()
            r.sleep()
    #############################################################
    def powerBoardVoltages(self, msg):
    #############################################################
        self.cur_voltage = msg.values[6].value

    #############################################################
    def spinOnce(self):
    #############################################################
        if self.full_calibration:
            for script in self.safty_scripts:
                script_calibrated = False
                script_calibrated = rospy.get_param('scripts_calibration/' + script + '/script_calibrated', False)
                if script_calibrated: pass
                while not script_calibrated and not rospy.is_shutdown():
                    script_calibrated = rospy.get_param('scripts_calibration/' + script + '/script_calibrated', False)
                    is_script = False
                    rospy.sleep(1.)
                    if self.can_run_script and rospy.get_time() - self.last_recieved_msg_time < 0.5 and self.calibration_step == 6:
                        self.can_run_script = False
                        rospy.sleep(5.)
                        script_calibrated = rospy.get_param('scripts_calibration/' + script + '/script_calibrated', False)
                        if not script_calibrated:
                            rospy.loginfo("calibration run %s" % script)
                            try:
                                script_resp = self.script_srv(script)
                                is_script   = script_resp.ok
                            except rospy.ServiceException, e:
                                rospy.logerr("Service call failed: %s"%e)
                        else: self.can_run_script = True

            self.full_calibration = False
        if self.check_calibration:
            for script in self.safty_scripts:
                if not self.check_calibration: return
                is_script = False
                while not is_script and not rospy.is_shutdown():
                    if not self.check_calibration: return
                    rospy.sleep(1.)
                    if self.can_run_script and rospy.get_time() - self.last_recieved_msg_time < 0.5 and self.calibration_step == 6:
#                        self.can_run_script = False
                        rospy.sleep(5.)
                        rospy.loginfo("check run %s" % script)
                        try:
                            script_resp = self.script_srv(script)
                            is_script   = script_resp.ok
                        except rospy.ServiceException, e:
                            rospy.logerr("Service call failed: %s"%e)
			self.can_run_script = not is_script


    #############################################################
    def servosCallback(self,msg):
        self.last_recieved_msg_time = rospy.get_time()
    #############################################################
        self.servos_prev = self.servos
        self.servos = msg
        if not self.script_calibrated and self.is_script:
            for servo in self.servos.states: # motor issue
                if servo.name in self.joints:
                    if self.wait_for_start and servo.setPoint != 0 and servo.torque: self.wait_for_start = False
                    if not self.wait_for_start:
                        self.appendMotorCur(servo.name,servo.motorCurrent)
                        motor_cur = numpy.mean(self.motor_cur_arr[servo.name])
                        vel = servo.position - [x.position for x in self.servos_prev.states if x.name == servo.name][0]
                        self.servos_calibration[servo.name].append(motor_cur)
                        self.servos_calibration_vel[servo.name].append(vel)
                        if self.is_debug:
                            msg_tmp = std_msgs.msg.Int16()
                            msg_tmp.data = vel
                            self.pub_test_vel[servo.name].publish(msg_tmp)
                            msg_tmp.data = servo.position
                            self.pub_test_pos[servo.name].publish(msg_tmp)
                            msg_tmp.data = motor_cur
                            self.pub_test_cur[servo.name].publish(msg_tmp)

            if not self.wait_for_start: self.count += 1
        elif self.is_script:
            output = ""
            for servo in self.servos.states: # motor issue
                if servo.fault_code != 0:
                    self.have_error = True
                    self.left_arm_error = 'left_' in servo.name and 'OBSTACLE_DETECTED' in servo.fault_code_str
                    self.right_arm_error = 'right_' in servo.name and 'OBSTACLE_DETECTED' in servo.fault_code_str
                if servo.name in self.joints:
                    if self.wait_for_start and servo.setPoint != 0 and servo.torque: self.wait_for_start = False
                    if not self.wait_for_start:
                        self.appendMotorCur(servo.name,servo.motorCurrent)
                        motor_cur = numpy.mean(self.motor_cur_arr[servo.name])
                        vel = servo.position - [x.position for x in self.servos_prev.states if x.name == servo.name][0]
                        self.servos_calibration[servo.name].append(motor_cur)
                        self.servos_calibration_vel[servo.name].append(vel)
                        if self.is_debug:
                            msg_tmp = std_msgs.msg.Int16()
                            if self.count < len(self.servos_avg_calibration_vel[servo.name]) and len(self.servos_avg_calibration_vel[servo.name]): msg_tmp.data = self.servos_avg_calibration_vel[servo.name][self.count]
                            else: msg_tmp.data = 0
                            self.pub_test_vel[servo.name].publish(msg_tmp)
                            msg_tmp.data = servo.position/100
                            self.pub_test_pos[servo.name].publish(msg_tmp)
                            msg_tmp.data = motor_cur
                            self.pub_test_cur[servo.name].publish(msg_tmp)
                            msg_tmp_float = std_msgs.msg.Float32()
    #                        if len(self.servos_avg_calibration[servo.name]): msg_tmp_float.data = self.servos_avg_calibration[servo.name][self.count] - self.servos_avg_calibration[servo.name][self.count+1]
    #                        else: msg_tmp_float.data = 0
    #                        self.pub_test_s[servo.name].publish(msg_tmp_float)
                            if self.count < len(self.servos_max_diff[servo.name]) and len(self.servos_max_diff[servo.name]): msg_tmp_float.data = self.servos_max_diff[servo.name][self.count]
                            else: msg_tmp_float.data = 0
                            self.pub_test_max_diff[servo.name].publish(msg_tmp_float)
                            if self.count < len(self.servos_avg_calibration[servo.name]) and len(self.servos_avg_calibration[servo.name]): msg_tmp.data = self.servos_avg_calibration[servo.name][self.count]
                            else: msg_tmp.data = 0
                            self.pub_test_calib[servo.name].publish(msg_tmp)
            if not self.wait_for_start: self.count += 1
        else:
            self.max_error = 0
            self.count = 0
            self.have_error = False
            self.right_arm_canceled = False
            self.left_arm_canceled  = False
            self.wait_for_start = True

    #############################################################

    #############################################################
    def startCalibrateCallback(self,msg):
    #############################################################
        self.full_calibration = True

    #############################################################
    def checkScriptsCallback(self,msg):
    #############################################################
        self.check_calibration = msg.data
        self.all_scripts_runs       = 0
        self.failure_scripts_runs   = 0
        for script in self.safty_scripts:
            if self.statistics[script]['all_runs'] != 0: rospy.loginfo("check result: %s error %f" % (script, 1.0 * self.statistics[script]['failure']/self.statistics[script]['all_runs']))
            self.statistics[script] = {'all_runs': 0, 'failure': 0}

    #############################################################
    def scriptCallback(self,msg):
    #############################################################
        self.safty_scripts = []
        self.safty_scripts = rospy.get_param('scripts_calibration/safty_scripts', [])
#        for script in self.safty_scripts:
#            self.statistics[script] = {'all_runs': 0, 'failure': 0}

        if msg.name not in self.safty_scripts: return
        self.is_script_prev = self.is_script
        self.is_script = msg.process
        if not self.is_script: self.can_run_script = True
        x = threading.Thread(target=self.processScript(msg), args=(1,))
        x.start()

    #############################################################
    def processScript(self,msg):
    #############################################################
        if self.is_script:
            self.prev_script_name = self.cur_script_name
            self.cur_script_name = msg.name
            self.script_calibrated = rospy.get_param('scripts_calibration/' + self.cur_script_name + '/script_calibrated', False)
            self.use_safety_arms = rospy.get_param('scripts_calibration/' + self.cur_script_name + '/use_safety_arms', True)
            if self.script_calibrated:
                for key in self.joints:
                    self.servos_avg_calibration[key] = rospy.get_param('scripts_calibration/' + self.cur_script_name + '/avg/' + key)
                    self.servos_avg_calibration_vel[key] = rospy.get_param('scripts_calibration/' + self.cur_script_name + '/vel/' + key)
                    self.servos_max_diff[key] = rospy.get_param('scripts_calibration/' + self.cur_script_name + '/max_diff/' + key)
                    self.servos_calibration_data[key] = numpy.array(rospy.get_param('scripts_calibration/' + self.cur_script_name + '/arr/' + key))

            if not self.script_calibrated and self.cur_script_name != self.prev_script_name:
                self.script_calibration_count = 0
                for joint in self.joints:
                    self.servos_all_calibration = []
                    self.servos_all_calibration_vel = []
                    self.motor_cur_arr[joint] = [0] * self.motor_cur_arr_size
                    self.servos_calibration[joint] = []
                    self.servos_calibration_vel[joint] = []
                    self.servos_calibration_data[joint] = []
                    self.servos_calibration_data_vel[joint] = []
                    self.servos_avg_calibration[joint] = []
                    self.servos_avg_calibration_vel[joint] = []
                    self.servos_max_diff[joint] = []
                    self.servos_s_calibration[joint] = []

        if not self.is_script and self.is_script_prev and not self.have_error and rospy.get_time() - self.last_recieved_msg_time < 0.5 and self.calibration_step == 6 and not self.wait_for_start:
            if not self.script_calibrated:
                self.servos_all_calibration.append(self.servos_calibration.copy())
                self.servos_all_calibration_vel.append(self.servos_calibration_vel.copy())
                self.script_calibration_count += 1
                if self.script_calibration_count >= self.max_calibraion_count:
                    self.script_calibrated = True
                    for joint in self.joints:
                        self.servos_calibration_data[joint] = numpy.zeros(( len(self.servos_calibration[joint]), self.max_calibraion_count ))
                        self.servos_calibration_data_vel[joint] = numpy.zeros(( len(self.servos_calibration_vel[joint]), self.max_calibraion_count ))
                    for key in self.joints:
                        k = 0
                        for calib_values in self.servos_all_calibration:
                            i = 0
                            for value in calib_values[key]:
                                if i < len(self.servos_calibration_data[key]):
                                    self.servos_calibration_data[key][i][k] = value
                                i += 1
                            k += 1
                        k = 0
                        for calib_values in self.servos_all_calibration_vel:
                            i = 0
                            for value in calib_values[key]:
                                if i < len(self.servos_calibration_data_vel[key]):
                                    self.servos_calibration_data_vel[key][i][k] = value
                                i += 1
                            k += 1

                    for key in self.servos_calibration_data:
                        for values in self.servos_calibration_data[key]:
                            xm = numpy.mean(values)  # среднее значение
                            xs = self.getS(values)#numpy.std(values)   # СКО
                            max_diff = abs(max(values) - min(values))
                            self.servos_avg_calibration[key].append(round(xm,3))
                            self.servos_s_calibration[key].append(round(xs,3))
                            self.servos_max_diff[key].append(round(max_diff,3))
                    for key in self.servos_calibration_data_vel:
                        for values in self.servos_calibration_data_vel[key]:
                            xm = numpy.mean(values)  # среднее значение
                            self.servos_avg_calibration_vel[key].append(round(xm,3))
                    self.setParams()
            else:
                for key in self.joints:
                    self.servos_avg_calibration[key] = []
                    self.servos_max_diff[key] = []
                    self.servos_s_calibration[key] = []

                    i = 0
                    for calib_values in self.servos_calibration_data[key]:
                        if i < len(self.servos_calibration[key]):
                            tmp_array_end = self.servos_calibration_data[key][i][self.max_calibraion_count/2 + 1:].tolist()
                            tmp_array_start = self.servos_calibration_data[key][i][:self.max_calibraion_count - self.max_calibraion_count/2].tolist()
                            tmp_array_end.append(self.servos_calibration[key][i])
                            self.servos_calibration_data[key][i] = numpy.array([tmp_array_start+tmp_array_end])
                            i += 1

                for key in self.servos_calibration_data:
                    for values in self.servos_calibration_data[key]:
                        xm = numpy.mean(values)  # среднее значение
                        xs = self.getS(values)#numpy.std(values)   # СКО
                        max_diff = abs(max(values) - min(values))
                        self.servos_avg_calibration[key].append(round(xm,3))
                        self.servos_s_calibration[key].append(round(xs,3))
                        self.servos_max_diff[key].append(round(max_diff,3))
                self.setParams()

        if not self.is_script: self.wait_for_start = True

        if not self.is_script and self.is_script_prev:
            if rospy.get_time() - self.last_recieved_msg_time < 0.5 and self.calibration_step == 6:
                if self.left_arm_error: self.pub_enable_left_arm.publish(std_msgs.msg.Empty())
                if self.right_arm_error: self.pub_enable_right_arm.publish(std_msgs.msg.Empty())
                if self.left_arm_error or self.right_arm_error: self.statistics[self.cur_script_name]['failure'] += 1
                self.statistics[self.cur_script_name]['all_runs'] += 1
                self.left_arm_error = self.right_arm_error = False
            for joint in self.joints:
                self.motor_cur_arr[joint] = [0] * self.motor_cur_arr_size
                self.servos_calibration[joint] = []
                self.servos_calibration_vel[joint] = []
                self.servos_calibration_data[joint] = []
                self.servos_calibration_data_vel[joint] = []
                self.servos_avg_calibration[joint] = []
                self.servos_avg_calibration_vel[joint] = []
                self.servos_max_diff[joint] = []
                self.servos_s_calibration[joint] = []

    #############################################################
    def calibrationStepCallback(self,msg):
    #############################################################
        self.calibration_step = msg.data
	if self.can_run_script == 6: self.can_run_script = True
        rospy.loginfo("calibration_step: %i" % self.calibration_step)

    #############################################################
    def calibrationStart(self,msg):
    #############################################################
        self.is_scripts_calibrating = msg.data

    #############################################################

    #############################################################
    def setParams(self):
    #############################################################
        if not self.use_safety_arms: return
        rospy.set_param('scripts_calibration/' + self.cur_script_name + '/script_calibrated', True)
        rospy.set_param('scripts_calibration/' + self.cur_script_name + '/main_voltage', self.cur_voltage)
        for key in self.servos_calibration_data:
            rospy.set_param('scripts_calibration/' + self.cur_script_name + '/avg/' + key, self.servos_avg_calibration[key])
            rospy.set_param('scripts_calibration/' + self.cur_script_name + '/vel/' + key, self.servos_avg_calibration_vel[key])
            rospy.set_param('scripts_calibration/' + self.cur_script_name + '/max_diff/' + key, self.servos_max_diff[key])
            rospy.set_param('scripts_calibration/' + self.cur_script_name + '/arr/' + key, self.servos_calibration_data[key].tolist())
        bashCommand = "rosparam dump $(catkin_find --share promobot_control)/config/scripts_calibration/%s.yaml /scripts_calibration/%s/" % (self.cur_script_name, self.cur_script_name)
        rospack = rospkg.RosPack()
        if not os.path.exists('%s/config/scripts_calibration/' % rospack.get_path('promobot_control')):
            os.mkdir('%s/config/scripts_calibration/' % rospack.get_path('promobot_control'))
        rosparam.dump_params('%s/config/scripts_calibration/%s.yaml' % (rospack.get_path('promobot_control'), self.cur_script_name), '/scripts_calibration/%s/' % self.cur_script_name )
#        output = subprocess.check_output(['bash','-c', '-i', bashCommand])
    #############################################################

    def getS(self,data):
    #############################################################
        sum = 0
        for value in data:
            sum += (value - numpy.mean(data))**2
        s = math.sqrt(sum/len(data)/(len(data)-1))
        return s

    #############################################################

    #####################################################
    def appendMotorCur(self, joint, val):
    #####################################################
        self.motor_cur_arr[joint].append(val)
        del self.motor_cur_arr[joint][0]

    #####################################################
    def loadParams(self):
    #####################################################
        rospack = rospkg.RosPack()
        if not os.path.exists('%s/config/scripts_calibration/' % rospack.get_path('promobot_control')):
            os.mkdir('%s/config/scripts_calibration/' % rospack.get_path('promobot_control'))
        files = os.listdir('%s/config/scripts_calibration/' % rospack.get_path('promobot_control'))
        for file in files:
            rospy.loginfo("loading %s" % file)
            paramlist = rosparam.load_file('%s/config/scripts_calibration/%s' % (rospack.get_path('promobot_control'), file),'/scripts_calibration/%s' % file.split('.')[0])
            for params,ns in paramlist:
                rosparam.upload_params(ns, params)
        rospy.loginfo("calibrations files are loaded.")

    def md5(self, fname):
        hash_md5 = hashlib.md5()
        with open(fname, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

#############################################################
#############################################################
if __name__ == '__main__':
    """ main """
    servoMonitiong = None
    try:
        servoMonitiong = ServoMonitoring()
        servoMonitiong.spin()
    except rospy.ROSInterruptException:
        if servoMonitiong:
            servoMonitiong.full_calibration = False
            servoMonitiong.check_calibration = False
        pass

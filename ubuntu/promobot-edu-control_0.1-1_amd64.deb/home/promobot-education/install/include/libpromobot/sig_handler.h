#ifndef SIG_HANDLER_H
#define SIG_HANDLER_H

#include "promobot.h"

#include <ros/init.h>
#include <ros/this_node.h>

#include <signal.h>
#include <execinfo.h>

namespace promobot
{
void signalHandler( int sig )
{
    std::cerr << "signalHandler: " << sig << std::endl;

    if( sig == SIGINT || sig == SIGTERM )
    {
        if( ros::ok() ) ros::shutdown();
        else exit( 0 );
    }
    else if( sig == SIGABRT || sig == SIGSEGV || sig == SIGILL )
    {
        promobot::addLog( "system", str( boost::format( "Node '%s' crashed" ) % ros::this_node::getName() ) );

        std::string filename    = promobot::path( PromobotLocations::Log ) + "/" + promobot::getCurDate() + "/" + ros::this_node::getName() + ".exc";
        std::string error_text  = "[" + promobot::getCurTime() + "]: Error: signal %d\n";

        FILE *fp = fopen( filename.c_str(), "a" );
        fprintf( fp, error_text.c_str(), sig );
        fflush( fp );

        void *stack[50];
        size_t size = backtrace( stack, 50 );
        backtrace_symbols_fd( stack, size, fileno( fp ) );
        fclose( fp );

        exit( 1 );
    }
}
}

#endif // SIG_HANDLER_H

#ifndef UUID_H
#define UUID_H

#include <uuid/uuid.h>

#include <ostream>

class Uuid
{
public:
    Uuid():
        uuid()
    {
    }

    Uuid( const Uuid &other )
    {
        if( this != &other ) uuid_copy( this->uuid, other.uuid );
    }

    Uuid( const std::string &text ):
        uuid()
    {
        if( text.length() != 36 )
        {
            *this = Uuid();
            return;
        }

        uuid_parse( text.c_str(), this->uuid );
    }

    static Uuid create()
    {
        Uuid uuid;
        uuid_generate_random( uuid.uuid );
        return uuid;
    }

    std::string toString() const
    {
        char uuid_str[37];
        uuid_unparse_lower( uuid, uuid_str );
        return uuid_str;
    }

    bool isNull() const
    {
        return uuid_is_null( uuid );
    }

    Uuid &operator=( const Uuid &other )
    {
        if( this != &other ) uuid_copy( this->uuid, other.uuid );
        return *this;
    }

    Uuid &operator=( const std::string &text )
    {
        if( text.length() == 36 ) uuid_parse( text.c_str(), this->uuid );
        return *this;
    }

    bool operator==( const Uuid &uuid ) const
    {
        return ( uuid_compare( this->uuid, uuid.uuid ) == 0 ? true : false );
    }

    bool operator!=( const Uuid &uuid ) const
    {
        return ( uuid_compare( this->uuid, uuid.uuid ) != 0 ? true : false );
    }

private:
    uuid_t uuid;
};

inline std::ostream &operator<<( std::ostream &stream, const Uuid &uuid )
{
    stream <<  "{" << uuid.toString() << "}";
    return stream;
}

#endif // UUID_H

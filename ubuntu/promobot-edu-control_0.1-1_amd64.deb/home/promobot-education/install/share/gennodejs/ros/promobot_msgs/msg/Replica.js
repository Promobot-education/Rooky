// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ID = require('./ID.js');

//-----------------------------------------------------------

class Replica {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.category = null;
      this.anchor = null;
      this.text = null;
      this.screentext = null;
      this.url = null;
      this.action = null;
      this.animation = null;
      this.type = null;
      this.interrupt_by_hark = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = new ID();
      }
      if (initObj.hasOwnProperty('category')) {
        this.category = initObj.category
      }
      else {
        this.category = new ID();
      }
      if (initObj.hasOwnProperty('anchor')) {
        this.anchor = initObj.anchor
      }
      else {
        this.anchor = new ID();
      }
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('screentext')) {
        this.screentext = initObj.screentext
      }
      else {
        this.screentext = '';
      }
      if (initObj.hasOwnProperty('url')) {
        this.url = initObj.url
      }
      else {
        this.url = '';
      }
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = '';
      }
      if (initObj.hasOwnProperty('animation')) {
        this.animation = initObj.animation
      }
      else {
        this.animation = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('interrupt_by_hark')) {
        this.interrupt_by_hark = initObj.interrupt_by_hark
      }
      else {
        this.interrupt_by_hark = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Replica
    // Serialize message field [id]
    bufferOffset = ID.serialize(obj.id, buffer, bufferOffset);
    // Serialize message field [category]
    bufferOffset = ID.serialize(obj.category, buffer, bufferOffset);
    // Serialize message field [anchor]
    bufferOffset = ID.serialize(obj.anchor, buffer, bufferOffset);
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [screentext]
    bufferOffset = _serializer.string(obj.screentext, buffer, bufferOffset);
    // Serialize message field [url]
    bufferOffset = _serializer.string(obj.url, buffer, bufferOffset);
    // Serialize message field [action]
    bufferOffset = _serializer.string(obj.action, buffer, bufferOffset);
    // Serialize message field [animation]
    bufferOffset = _serializer.uint8(obj.animation, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint16(obj.type, buffer, bufferOffset);
    // Serialize message field [interrupt_by_hark]
    bufferOffset = _serializer.bool(obj.interrupt_by_hark, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Replica
    let len;
    let data = new Replica(null);
    // Deserialize message field [id]
    data.id = ID.deserialize(buffer, bufferOffset);
    // Deserialize message field [category]
    data.category = ID.deserialize(buffer, bufferOffset);
    // Deserialize message field [anchor]
    data.anchor = ID.deserialize(buffer, bufferOffset);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [screentext]
    data.screentext = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [url]
    data.url = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [action]
    data.action = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [animation]
    data.animation = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [interrupt_by_hark]
    data.interrupt_by_hark = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += ID.getMessageSize(object.id);
    length += ID.getMessageSize(object.category);
    length += ID.getMessageSize(object.anchor);
    length += object.text.length;
    length += object.screentext.length;
    length += object.url.length;
    length += object.action.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Replica';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8ec6ad175fdab33b1258574c92560215';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/ID id
    promobot_msgs/ID category
    promobot_msgs/ID anchor
    string text
    string screentext
    string url
    string action
    uint8 animation
    uint16 type
    bool interrupt_by_hark
    
    ================================================================================
    MSG: promobot_msgs/ID
    uint32 id
    string uuid
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Replica(null);
    if (msg.id !== undefined) {
      resolved.id = ID.Resolve(msg.id)
    }
    else {
      resolved.id = new ID()
    }

    if (msg.category !== undefined) {
      resolved.category = ID.Resolve(msg.category)
    }
    else {
      resolved.category = new ID()
    }

    if (msg.anchor !== undefined) {
      resolved.anchor = ID.Resolve(msg.anchor)
    }
    else {
      resolved.anchor = new ID()
    }

    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.screentext !== undefined) {
      resolved.screentext = msg.screentext;
    }
    else {
      resolved.screentext = ''
    }

    if (msg.url !== undefined) {
      resolved.url = msg.url;
    }
    else {
      resolved.url = ''
    }

    if (msg.action !== undefined) {
      resolved.action = msg.action;
    }
    else {
      resolved.action = ''
    }

    if (msg.animation !== undefined) {
      resolved.animation = msg.animation;
    }
    else {
      resolved.animation = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.interrupt_by_hark !== undefined) {
      resolved.interrupt_by_hark = msg.interrupt_by_hark;
    }
    else {
      resolved.interrupt_by_hark = false
    }

    return resolved;
    }
};

module.exports = Replica;

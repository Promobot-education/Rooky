// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let People = require('./People.js');

//-----------------------------------------------------------

class PeopleArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.peoples = null;
    }
    else {
      if (initObj.hasOwnProperty('peoples')) {
        this.peoples = initObj.peoples
      }
      else {
        this.peoples = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PeopleArray
    // Serialize message field [peoples]
    // Serialize the length for message field [peoples]
    bufferOffset = _serializer.uint32(obj.peoples.length, buffer, bufferOffset);
    obj.peoples.forEach((val) => {
      bufferOffset = People.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PeopleArray
    let len;
    let data = new PeopleArray(null);
    // Deserialize message field [peoples]
    // Deserialize array length for message field [peoples]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.peoples = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.peoples[i] = People.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 28 * object.peoples.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/PeopleArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f35e129ec60e0af5833d344aceb3bb56';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/People[] peoples
    
    ================================================================================
    MSG: promobot_msgs/People
    float32 id
    geometry_msgs/Point point
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PeopleArray(null);
    if (msg.peoples !== undefined) {
      resolved.peoples = new Array(msg.peoples.length);
      for (let i = 0; i < resolved.peoples.length; ++i) {
        resolved.peoples[i] = People.Resolve(msg.peoples[i]);
      }
    }
    else {
      resolved.peoples = []
    }

    return resolved;
    }
};

module.exports = PeopleArray;

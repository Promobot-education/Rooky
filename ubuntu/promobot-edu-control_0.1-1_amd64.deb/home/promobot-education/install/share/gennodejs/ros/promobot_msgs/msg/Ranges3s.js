// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Ranges3s {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.s_1 = null;
      this.s_2 = null;
      this.s_3 = null;
      this.s_4 = null;
      this.s_5 = null;
      this.s_6 = null;
      this.s_7 = null;
      this.s_8 = null;
      this.s_9 = null;
      this.s_10 = null;
      this.s_11 = null;
      this.s_12 = null;
      this.s_13 = null;
      this.s_14 = null;
      this.s_15 = null;
      this.s_16 = null;
      this.s_66 = null;
    }
    else {
      if (initObj.hasOwnProperty('s_1')) {
        this.s_1 = initObj.s_1
      }
      else {
        this.s_1 = 0;
      }
      if (initObj.hasOwnProperty('s_2')) {
        this.s_2 = initObj.s_2
      }
      else {
        this.s_2 = 0;
      }
      if (initObj.hasOwnProperty('s_3')) {
        this.s_3 = initObj.s_3
      }
      else {
        this.s_3 = 0;
      }
      if (initObj.hasOwnProperty('s_4')) {
        this.s_4 = initObj.s_4
      }
      else {
        this.s_4 = 0;
      }
      if (initObj.hasOwnProperty('s_5')) {
        this.s_5 = initObj.s_5
      }
      else {
        this.s_5 = 0;
      }
      if (initObj.hasOwnProperty('s_6')) {
        this.s_6 = initObj.s_6
      }
      else {
        this.s_6 = 0;
      }
      if (initObj.hasOwnProperty('s_7')) {
        this.s_7 = initObj.s_7
      }
      else {
        this.s_7 = 0;
      }
      if (initObj.hasOwnProperty('s_8')) {
        this.s_8 = initObj.s_8
      }
      else {
        this.s_8 = 0;
      }
      if (initObj.hasOwnProperty('s_9')) {
        this.s_9 = initObj.s_9
      }
      else {
        this.s_9 = 0;
      }
      if (initObj.hasOwnProperty('s_10')) {
        this.s_10 = initObj.s_10
      }
      else {
        this.s_10 = 0;
      }
      if (initObj.hasOwnProperty('s_11')) {
        this.s_11 = initObj.s_11
      }
      else {
        this.s_11 = 0;
      }
      if (initObj.hasOwnProperty('s_12')) {
        this.s_12 = initObj.s_12
      }
      else {
        this.s_12 = 0;
      }
      if (initObj.hasOwnProperty('s_13')) {
        this.s_13 = initObj.s_13
      }
      else {
        this.s_13 = 0;
      }
      if (initObj.hasOwnProperty('s_14')) {
        this.s_14 = initObj.s_14
      }
      else {
        this.s_14 = 0;
      }
      if (initObj.hasOwnProperty('s_15')) {
        this.s_15 = initObj.s_15
      }
      else {
        this.s_15 = 0;
      }
      if (initObj.hasOwnProperty('s_16')) {
        this.s_16 = initObj.s_16
      }
      else {
        this.s_16 = 0;
      }
      if (initObj.hasOwnProperty('s_66')) {
        this.s_66 = initObj.s_66
      }
      else {
        this.s_66 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Ranges3s
    // Serialize message field [s_1]
    bufferOffset = _serializer.uint8(obj.s_1, buffer, bufferOffset);
    // Serialize message field [s_2]
    bufferOffset = _serializer.uint8(obj.s_2, buffer, bufferOffset);
    // Serialize message field [s_3]
    bufferOffset = _serializer.uint8(obj.s_3, buffer, bufferOffset);
    // Serialize message field [s_4]
    bufferOffset = _serializer.uint8(obj.s_4, buffer, bufferOffset);
    // Serialize message field [s_5]
    bufferOffset = _serializer.uint8(obj.s_5, buffer, bufferOffset);
    // Serialize message field [s_6]
    bufferOffset = _serializer.uint8(obj.s_6, buffer, bufferOffset);
    // Serialize message field [s_7]
    bufferOffset = _serializer.uint8(obj.s_7, buffer, bufferOffset);
    // Serialize message field [s_8]
    bufferOffset = _serializer.uint8(obj.s_8, buffer, bufferOffset);
    // Serialize message field [s_9]
    bufferOffset = _serializer.uint8(obj.s_9, buffer, bufferOffset);
    // Serialize message field [s_10]
    bufferOffset = _serializer.uint8(obj.s_10, buffer, bufferOffset);
    // Serialize message field [s_11]
    bufferOffset = _serializer.uint8(obj.s_11, buffer, bufferOffset);
    // Serialize message field [s_12]
    bufferOffset = _serializer.uint8(obj.s_12, buffer, bufferOffset);
    // Serialize message field [s_13]
    bufferOffset = _serializer.uint8(obj.s_13, buffer, bufferOffset);
    // Serialize message field [s_14]
    bufferOffset = _serializer.uint8(obj.s_14, buffer, bufferOffset);
    // Serialize message field [s_15]
    bufferOffset = _serializer.uint8(obj.s_15, buffer, bufferOffset);
    // Serialize message field [s_16]
    bufferOffset = _serializer.uint8(obj.s_16, buffer, bufferOffset);
    // Serialize message field [s_66]
    bufferOffset = _serializer.uint8(obj.s_66, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Ranges3s
    let len;
    let data = new Ranges3s(null);
    // Deserialize message field [s_1]
    data.s_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_2]
    data.s_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_3]
    data.s_3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_4]
    data.s_4 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_5]
    data.s_5 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_6]
    data.s_6 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_7]
    data.s_7 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_8]
    data.s_8 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_9]
    data.s_9 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_10]
    data.s_10 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_11]
    data.s_11 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_12]
    data.s_12 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_13]
    data.s_13 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_14]
    data.s_14 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_15]
    data.s_15 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_16]
    data.s_16 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_66]
    data.s_66 = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Ranges3s';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3867b8d7e7fcfd62ac9574558ca1da16';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 s_1  #
    uint8 s_2  #            8  7  6
    uint8 s_3  #       9               5
    uint8 s_4  #           _________
    uint8 s_5  #     10   /         \    4
    uint8 s_6  #         |           |
    uint8 s_7  #     11  |           |   3
    uint8 s_8  #         \           /
    uint8 s_9  #     12   \         /   2
    uint8 s_10 #           \       /
    uint8 s_11 #       13   \_____/   1
    uint8 s_12 #
    uint8 s_13 #          14  15  16
    uint8 s_14 #
    uint8 s_15 #
    uint8 s_16 #
    uint8 s_66 #
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Ranges3s(null);
    if (msg.s_1 !== undefined) {
      resolved.s_1 = msg.s_1;
    }
    else {
      resolved.s_1 = 0
    }

    if (msg.s_2 !== undefined) {
      resolved.s_2 = msg.s_2;
    }
    else {
      resolved.s_2 = 0
    }

    if (msg.s_3 !== undefined) {
      resolved.s_3 = msg.s_3;
    }
    else {
      resolved.s_3 = 0
    }

    if (msg.s_4 !== undefined) {
      resolved.s_4 = msg.s_4;
    }
    else {
      resolved.s_4 = 0
    }

    if (msg.s_5 !== undefined) {
      resolved.s_5 = msg.s_5;
    }
    else {
      resolved.s_5 = 0
    }

    if (msg.s_6 !== undefined) {
      resolved.s_6 = msg.s_6;
    }
    else {
      resolved.s_6 = 0
    }

    if (msg.s_7 !== undefined) {
      resolved.s_7 = msg.s_7;
    }
    else {
      resolved.s_7 = 0
    }

    if (msg.s_8 !== undefined) {
      resolved.s_8 = msg.s_8;
    }
    else {
      resolved.s_8 = 0
    }

    if (msg.s_9 !== undefined) {
      resolved.s_9 = msg.s_9;
    }
    else {
      resolved.s_9 = 0
    }

    if (msg.s_10 !== undefined) {
      resolved.s_10 = msg.s_10;
    }
    else {
      resolved.s_10 = 0
    }

    if (msg.s_11 !== undefined) {
      resolved.s_11 = msg.s_11;
    }
    else {
      resolved.s_11 = 0
    }

    if (msg.s_12 !== undefined) {
      resolved.s_12 = msg.s_12;
    }
    else {
      resolved.s_12 = 0
    }

    if (msg.s_13 !== undefined) {
      resolved.s_13 = msg.s_13;
    }
    else {
      resolved.s_13 = 0
    }

    if (msg.s_14 !== undefined) {
      resolved.s_14 = msg.s_14;
    }
    else {
      resolved.s_14 = 0
    }

    if (msg.s_15 !== undefined) {
      resolved.s_15 = msg.s_15;
    }
    else {
      resolved.s_15 = 0
    }

    if (msg.s_16 !== undefined) {
      resolved.s_16 = msg.s_16;
    }
    else {
      resolved.s_16 = 0
    }

    if (msg.s_66 !== undefined) {
      resolved.s_66 = msg.s_66;
    }
    else {
      resolved.s_66 = 0
    }

    return resolved;
    }
};

module.exports = Ranges3s;

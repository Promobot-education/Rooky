// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PowerBoardState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.firmware = null;
      this.main_off_timeout = null;
      this.robot_off_timeout = null;
      this.power_command = null;
      this.zummer_command = null;
      this.modbus_status = null;
      this.status_USB_1 = null;
      this.status_USB_2 = null;
      this.status_USB_3 = null;
      this.status_USB_4 = null;
      this.status_USB_5 = null;
      this.status_USB_6 = null;
      this.status_USB_7 = null;
      this.mainboard_poll_erros = null;
      this.mainboard_poll_freq = null;
      this.bottom_board_poll_freq = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = 0;
      }
      if (initObj.hasOwnProperty('firmware')) {
        this.firmware = initObj.firmware
      }
      else {
        this.firmware = 0;
      }
      if (initObj.hasOwnProperty('main_off_timeout')) {
        this.main_off_timeout = initObj.main_off_timeout
      }
      else {
        this.main_off_timeout = 0;
      }
      if (initObj.hasOwnProperty('robot_off_timeout')) {
        this.robot_off_timeout = initObj.robot_off_timeout
      }
      else {
        this.robot_off_timeout = 0;
      }
      if (initObj.hasOwnProperty('power_command')) {
        this.power_command = initObj.power_command
      }
      else {
        this.power_command = 0;
      }
      if (initObj.hasOwnProperty('zummer_command')) {
        this.zummer_command = initObj.zummer_command
      }
      else {
        this.zummer_command = 0;
      }
      if (initObj.hasOwnProperty('modbus_status')) {
        this.modbus_status = initObj.modbus_status
      }
      else {
        this.modbus_status = 0;
      }
      if (initObj.hasOwnProperty('status_USB_1')) {
        this.status_USB_1 = initObj.status_USB_1
      }
      else {
        this.status_USB_1 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_2')) {
        this.status_USB_2 = initObj.status_USB_2
      }
      else {
        this.status_USB_2 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_3')) {
        this.status_USB_3 = initObj.status_USB_3
      }
      else {
        this.status_USB_3 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_4')) {
        this.status_USB_4 = initObj.status_USB_4
      }
      else {
        this.status_USB_4 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_5')) {
        this.status_USB_5 = initObj.status_USB_5
      }
      else {
        this.status_USB_5 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_6')) {
        this.status_USB_6 = initObj.status_USB_6
      }
      else {
        this.status_USB_6 = 0;
      }
      if (initObj.hasOwnProperty('status_USB_7')) {
        this.status_USB_7 = initObj.status_USB_7
      }
      else {
        this.status_USB_7 = 0;
      }
      if (initObj.hasOwnProperty('mainboard_poll_erros')) {
        this.mainboard_poll_erros = initObj.mainboard_poll_erros
      }
      else {
        this.mainboard_poll_erros = 0;
      }
      if (initObj.hasOwnProperty('mainboard_poll_freq')) {
        this.mainboard_poll_freq = initObj.mainboard_poll_freq
      }
      else {
        this.mainboard_poll_freq = 0;
      }
      if (initObj.hasOwnProperty('bottom_board_poll_freq')) {
        this.bottom_board_poll_freq = initObj.bottom_board_poll_freq
      }
      else {
        this.bottom_board_poll_freq = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PowerBoardState
    // Serialize message field [timestamp]
    bufferOffset = _serializer.uint32(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [firmware]
    bufferOffset = _serializer.uint16(obj.firmware, buffer, bufferOffset);
    // Serialize message field [main_off_timeout]
    bufferOffset = _serializer.uint16(obj.main_off_timeout, buffer, bufferOffset);
    // Serialize message field [robot_off_timeout]
    bufferOffset = _serializer.uint16(obj.robot_off_timeout, buffer, bufferOffset);
    // Serialize message field [power_command]
    bufferOffset = _serializer.uint16(obj.power_command, buffer, bufferOffset);
    // Serialize message field [zummer_command]
    bufferOffset = _serializer.uint16(obj.zummer_command, buffer, bufferOffset);
    // Serialize message field [modbus_status]
    bufferOffset = _serializer.uint16(obj.modbus_status, buffer, bufferOffset);
    // Serialize message field [status_USB_1]
    bufferOffset = _serializer.uint16(obj.status_USB_1, buffer, bufferOffset);
    // Serialize message field [status_USB_2]
    bufferOffset = _serializer.uint16(obj.status_USB_2, buffer, bufferOffset);
    // Serialize message field [status_USB_3]
    bufferOffset = _serializer.uint16(obj.status_USB_3, buffer, bufferOffset);
    // Serialize message field [status_USB_4]
    bufferOffset = _serializer.uint16(obj.status_USB_4, buffer, bufferOffset);
    // Serialize message field [status_USB_5]
    bufferOffset = _serializer.uint16(obj.status_USB_5, buffer, bufferOffset);
    // Serialize message field [status_USB_6]
    bufferOffset = _serializer.uint16(obj.status_USB_6, buffer, bufferOffset);
    // Serialize message field [status_USB_7]
    bufferOffset = _serializer.uint16(obj.status_USB_7, buffer, bufferOffset);
    // Serialize message field [mainboard_poll_erros]
    bufferOffset = _serializer.uint16(obj.mainboard_poll_erros, buffer, bufferOffset);
    // Serialize message field [mainboard_poll_freq]
    bufferOffset = _serializer.uint16(obj.mainboard_poll_freq, buffer, bufferOffset);
    // Serialize message field [bottom_board_poll_freq]
    bufferOffset = _serializer.uint16(obj.bottom_board_poll_freq, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PowerBoardState
    let len;
    let data = new PowerBoardState(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [firmware]
    data.firmware = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [main_off_timeout]
    data.main_off_timeout = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [robot_off_timeout]
    data.robot_off_timeout = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [power_command]
    data.power_command = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [zummer_command]
    data.zummer_command = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [modbus_status]
    data.modbus_status = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_1]
    data.status_USB_1 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_2]
    data.status_USB_2 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_3]
    data.status_USB_3 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_4]
    data.status_USB_4 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_5]
    data.status_USB_5 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_6]
    data.status_USB_6 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [status_USB_7]
    data.status_USB_7 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [mainboard_poll_erros]
    data.mainboard_poll_erros = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [mainboard_poll_freq]
    data.mainboard_poll_freq = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [bottom_board_poll_freq]
    data.bottom_board_poll_freq = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/PowerBoardState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'be30eb4e0b6e8c42b5354c32cbe78fd6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 timestamp
    uint16 firmware
    
    uint16 main_off_timeout
    uint16 robot_off_timeout
    
    uint16 power_command
    uint16 zummer_command
    
    uint16 modbus_status
    uint16 status_USB_1
    uint16 status_USB_2
    uint16 status_USB_3
    uint16 status_USB_4
    uint16 status_USB_5
    uint16 status_USB_6
    uint16 status_USB_7
    
    uint16 mainboard_poll_erros
    uint16 mainboard_poll_freq
    uint16 bottom_board_poll_freq
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PowerBoardState(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = 0
    }

    if (msg.firmware !== undefined) {
      resolved.firmware = msg.firmware;
    }
    else {
      resolved.firmware = 0
    }

    if (msg.main_off_timeout !== undefined) {
      resolved.main_off_timeout = msg.main_off_timeout;
    }
    else {
      resolved.main_off_timeout = 0
    }

    if (msg.robot_off_timeout !== undefined) {
      resolved.robot_off_timeout = msg.robot_off_timeout;
    }
    else {
      resolved.robot_off_timeout = 0
    }

    if (msg.power_command !== undefined) {
      resolved.power_command = msg.power_command;
    }
    else {
      resolved.power_command = 0
    }

    if (msg.zummer_command !== undefined) {
      resolved.zummer_command = msg.zummer_command;
    }
    else {
      resolved.zummer_command = 0
    }

    if (msg.modbus_status !== undefined) {
      resolved.modbus_status = msg.modbus_status;
    }
    else {
      resolved.modbus_status = 0
    }

    if (msg.status_USB_1 !== undefined) {
      resolved.status_USB_1 = msg.status_USB_1;
    }
    else {
      resolved.status_USB_1 = 0
    }

    if (msg.status_USB_2 !== undefined) {
      resolved.status_USB_2 = msg.status_USB_2;
    }
    else {
      resolved.status_USB_2 = 0
    }

    if (msg.status_USB_3 !== undefined) {
      resolved.status_USB_3 = msg.status_USB_3;
    }
    else {
      resolved.status_USB_3 = 0
    }

    if (msg.status_USB_4 !== undefined) {
      resolved.status_USB_4 = msg.status_USB_4;
    }
    else {
      resolved.status_USB_4 = 0
    }

    if (msg.status_USB_5 !== undefined) {
      resolved.status_USB_5 = msg.status_USB_5;
    }
    else {
      resolved.status_USB_5 = 0
    }

    if (msg.status_USB_6 !== undefined) {
      resolved.status_USB_6 = msg.status_USB_6;
    }
    else {
      resolved.status_USB_6 = 0
    }

    if (msg.status_USB_7 !== undefined) {
      resolved.status_USB_7 = msg.status_USB_7;
    }
    else {
      resolved.status_USB_7 = 0
    }

    if (msg.mainboard_poll_erros !== undefined) {
      resolved.mainboard_poll_erros = msg.mainboard_poll_erros;
    }
    else {
      resolved.mainboard_poll_erros = 0
    }

    if (msg.mainboard_poll_freq !== undefined) {
      resolved.mainboard_poll_freq = msg.mainboard_poll_freq;
    }
    else {
      resolved.mainboard_poll_freq = 0
    }

    if (msg.bottom_board_poll_freq !== undefined) {
      resolved.bottom_board_poll_freq = msg.bottom_board_poll_freq;
    }
    else {
      resolved.bottom_board_poll_freq = 0
    }

    return resolved;
    }
};

module.exports = PowerBoardState;

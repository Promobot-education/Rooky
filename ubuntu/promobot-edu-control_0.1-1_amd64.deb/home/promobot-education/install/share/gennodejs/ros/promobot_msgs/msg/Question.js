// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Face = require('./Face.js');

//-----------------------------------------------------------

class Question {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.question = null;
      this.info = null;
    }
    else {
      if (initObj.hasOwnProperty('question')) {
        this.question = initObj.question
      }
      else {
        this.question = '';
      }
      if (initObj.hasOwnProperty('info')) {
        this.info = initObj.info
      }
      else {
        this.info = new Face();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Question
    // Serialize message field [question]
    bufferOffset = _serializer.string(obj.question, buffer, bufferOffset);
    // Serialize message field [info]
    bufferOffset = Face.serialize(obj.info, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Question
    let len;
    let data = new Question(null);
    // Deserialize message field [question]
    data.question = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [info]
    data.info = Face.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.question.length;
    length += Face.getMessageSize(object.info);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Question';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '72b309ba31de046440f386a8bd3cd363';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string question
    promobot_msgs/Face info
    
    ================================================================================
    MSG: promobot_msgs/Face
    uint8 type
    uint8 source
    bool is_tracking
    int64 track_id
    int64 id
    uint8 gender
    float32 age
    string emotion
    uint8 liveness_type
    promobot_msgs/FaceScore[] persons
    
    ================================================================================
    MSG: promobot_msgs/FaceScore
    uint8 source
    uint8 personSource
    int64 id
    float32 score
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Question(null);
    if (msg.question !== undefined) {
      resolved.question = msg.question;
    }
    else {
      resolved.question = ''
    }

    if (msg.info !== undefined) {
      resolved.info = Face.Resolve(msg.info)
    }
    else {
      resolved.info = new Face()
    }

    return resolved;
    }
};

module.exports = Question;

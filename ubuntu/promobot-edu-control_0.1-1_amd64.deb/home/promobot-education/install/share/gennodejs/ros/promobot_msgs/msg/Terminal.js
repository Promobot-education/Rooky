// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Terminal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.servo_position = null;
      this.servo_open_pos = null;
      this.servo_close_pos = null;
      this.open_delay = null;
      this.close_delay = null;
      this.koncevik_open = null;
      this.koncevik_close = null;
    }
    else {
      if (initObj.hasOwnProperty('servo_position')) {
        this.servo_position = initObj.servo_position
      }
      else {
        this.servo_position = 0;
      }
      if (initObj.hasOwnProperty('servo_open_pos')) {
        this.servo_open_pos = initObj.servo_open_pos
      }
      else {
        this.servo_open_pos = 0;
      }
      if (initObj.hasOwnProperty('servo_close_pos')) {
        this.servo_close_pos = initObj.servo_close_pos
      }
      else {
        this.servo_close_pos = 0;
      }
      if (initObj.hasOwnProperty('open_delay')) {
        this.open_delay = initObj.open_delay
      }
      else {
        this.open_delay = 0;
      }
      if (initObj.hasOwnProperty('close_delay')) {
        this.close_delay = initObj.close_delay
      }
      else {
        this.close_delay = 0;
      }
      if (initObj.hasOwnProperty('koncevik_open')) {
        this.koncevik_open = initObj.koncevik_open
      }
      else {
        this.koncevik_open = false;
      }
      if (initObj.hasOwnProperty('koncevik_close')) {
        this.koncevik_close = initObj.koncevik_close
      }
      else {
        this.koncevik_close = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Terminal
    // Serialize message field [servo_position]
    bufferOffset = _serializer.uint16(obj.servo_position, buffer, bufferOffset);
    // Serialize message field [servo_open_pos]
    bufferOffset = _serializer.uint16(obj.servo_open_pos, buffer, bufferOffset);
    // Serialize message field [servo_close_pos]
    bufferOffset = _serializer.uint16(obj.servo_close_pos, buffer, bufferOffset);
    // Serialize message field [open_delay]
    bufferOffset = _serializer.uint16(obj.open_delay, buffer, bufferOffset);
    // Serialize message field [close_delay]
    bufferOffset = _serializer.uint16(obj.close_delay, buffer, bufferOffset);
    // Serialize message field [koncevik_open]
    bufferOffset = _serializer.bool(obj.koncevik_open, buffer, bufferOffset);
    // Serialize message field [koncevik_close]
    bufferOffset = _serializer.bool(obj.koncevik_close, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Terminal
    let len;
    let data = new Terminal(null);
    // Deserialize message field [servo_position]
    data.servo_position = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [servo_open_pos]
    data.servo_open_pos = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [servo_close_pos]
    data.servo_close_pos = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [open_delay]
    data.open_delay = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [close_delay]
    data.close_delay = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [koncevik_open]
    data.koncevik_open = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [koncevik_close]
    data.koncevik_close = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Terminal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5da1d295ea13f74313a4cb653e4dcb32';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 servo_position
    uint16 servo_open_pos
    uint16 servo_close_pos
    uint16 open_delay
    uint16 close_delay
    bool koncevik_open
    bool koncevik_close
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Terminal(null);
    if (msg.servo_position !== undefined) {
      resolved.servo_position = msg.servo_position;
    }
    else {
      resolved.servo_position = 0
    }

    if (msg.servo_open_pos !== undefined) {
      resolved.servo_open_pos = msg.servo_open_pos;
    }
    else {
      resolved.servo_open_pos = 0
    }

    if (msg.servo_close_pos !== undefined) {
      resolved.servo_close_pos = msg.servo_close_pos;
    }
    else {
      resolved.servo_close_pos = 0
    }

    if (msg.open_delay !== undefined) {
      resolved.open_delay = msg.open_delay;
    }
    else {
      resolved.open_delay = 0
    }

    if (msg.close_delay !== undefined) {
      resolved.close_delay = msg.close_delay;
    }
    else {
      resolved.close_delay = 0
    }

    if (msg.koncevik_open !== undefined) {
      resolved.koncevik_open = msg.koncevik_open;
    }
    else {
      resolved.koncevik_open = false
    }

    if (msg.koncevik_close !== undefined) {
      resolved.koncevik_close = msg.koncevik_close;
    }
    else {
      resolved.koncevik_close = false
    }

    return resolved;
    }
};

module.exports = Terminal;

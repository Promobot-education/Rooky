// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class HallSensors {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.leftSensor = null;
      this.rightSensor = null;
    }
    else {
      if (initObj.hasOwnProperty('leftSensor')) {
        this.leftSensor = initObj.leftSensor
      }
      else {
        this.leftSensor = false;
      }
      if (initObj.hasOwnProperty('rightSensor')) {
        this.rightSensor = initObj.rightSensor
      }
      else {
        this.rightSensor = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type HallSensors
    // Serialize message field [leftSensor]
    bufferOffset = _serializer.bool(obj.leftSensor, buffer, bufferOffset);
    // Serialize message field [rightSensor]
    bufferOffset = _serializer.bool(obj.rightSensor, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type HallSensors
    let len;
    let data = new HallSensors(null);
    // Deserialize message field [leftSensor]
    data.leftSensor = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rightSensor]
    data.rightSensor = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/HallSensors';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06152f74a19a8d86ae4bab1462474dff';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool  	leftSensor	# Левый датчик крайнего положения
    bool  	rightSensor	# Правый датчик крайнего положения
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new HallSensors(null);
    if (msg.leftSensor !== undefined) {
      resolved.leftSensor = msg.leftSensor;
    }
    else {
      resolved.leftSensor = false
    }

    if (msg.rightSensor !== undefined) {
      resolved.rightSensor = msg.rightSensor;
    }
    else {
      resolved.rightSensor = false
    }

    return resolved;
    }
};

module.exports = HallSensors;

## Сборка 

Собрать с помощью catkin_make install.

После успешной сборки выполнить команду 

source install/setup.bash

## Запуск симуляции

Для запуска симуляции необходимо выполнить следующую последовательность команд

roslaunch promobot_description robot_model.launch type:=sim

roslaunch promobot_control promobot_simulation.launch

roslaunch promobot_description simulation_gazebo.launch

Появится окно gazebo с левой рукой робота

Для контроля полной функциональности также необходимо запустить 

rosrun rviz rviz

rosrun rqt_joint_trajectory_controller rqt_joint_trajectory_controller

В последнем открышемся окне необходимо выбрать контроллер и поуправлять рукой робота.



// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let promobot_msgs = _finder('promobot_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetAppReplicaRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.app_name = null;
      this.step = null;
      this.category = null;
      this.use_general = null;
      this.use_biometry = null;
      this.user_uuid = null;
      this.info = null;
    }
    else {
      if (initObj.hasOwnProperty('app_name')) {
        this.app_name = initObj.app_name
      }
      else {
        this.app_name = '';
      }
      if (initObj.hasOwnProperty('step')) {
        this.step = initObj.step
      }
      else {
        this.step = '';
      }
      if (initObj.hasOwnProperty('category')) {
        this.category = initObj.category
      }
      else {
        this.category = new promobot_msgs.msg.ID();
      }
      if (initObj.hasOwnProperty('use_general')) {
        this.use_general = initObj.use_general
      }
      else {
        this.use_general = false;
      }
      if (initObj.hasOwnProperty('use_biometry')) {
        this.use_biometry = initObj.use_biometry
      }
      else {
        this.use_biometry = false;
      }
      if (initObj.hasOwnProperty('user_uuid')) {
        this.user_uuid = initObj.user_uuid
      }
      else {
        this.user_uuid = '';
      }
      if (initObj.hasOwnProperty('info')) {
        this.info = initObj.info
      }
      else {
        this.info = new promobot_msgs.msg.Face();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAppReplicaRequest
    // Serialize message field [app_name]
    bufferOffset = _serializer.string(obj.app_name, buffer, bufferOffset);
    // Serialize message field [step]
    bufferOffset = _serializer.string(obj.step, buffer, bufferOffset);
    // Serialize message field [category]
    bufferOffset = promobot_msgs.msg.ID.serialize(obj.category, buffer, bufferOffset);
    // Serialize message field [use_general]
    bufferOffset = _serializer.bool(obj.use_general, buffer, bufferOffset);
    // Serialize message field [use_biometry]
    bufferOffset = _serializer.bool(obj.use_biometry, buffer, bufferOffset);
    // Serialize message field [user_uuid]
    bufferOffset = _serializer.string(obj.user_uuid, buffer, bufferOffset);
    // Serialize message field [info]
    bufferOffset = promobot_msgs.msg.Face.serialize(obj.info, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAppReplicaRequest
    let len;
    let data = new GetAppReplicaRequest(null);
    // Deserialize message field [app_name]
    data.app_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [step]
    data.step = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [category]
    data.category = promobot_msgs.msg.ID.deserialize(buffer, bufferOffset);
    // Deserialize message field [use_general]
    data.use_general = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [use_biometry]
    data.use_biometry = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [user_uuid]
    data.user_uuid = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [info]
    data.info = promobot_msgs.msg.Face.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.app_name.length;
    length += object.step.length;
    length += promobot_msgs.msg.ID.getMessageSize(object.category);
    length += object.user_uuid.length;
    length += promobot_msgs.msg.Face.getMessageSize(object.info);
    return length + 14;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/GetAppReplicaRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eec7679e2cd6478f19a00868ae37b962';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string app_name
    string step
    promobot_msgs/ID category
    bool use_general
    bool use_biometry
    string user_uuid
    promobot_msgs/Face info
    
    ================================================================================
    MSG: promobot_msgs/ID
    uint32 id
    string uuid
    
    ================================================================================
    MSG: promobot_msgs/Face
    uint8 type
    uint8 source
    bool is_tracking
    int64 track_id
    int64 id
    uint8 gender
    float32 age
    string emotion
    uint8 liveness_type
    promobot_msgs/FaceScore[] persons
    
    ================================================================================
    MSG: promobot_msgs/FaceScore
    uint8 source
    uint8 personSource
    int64 id
    float32 score
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAppReplicaRequest(null);
    if (msg.app_name !== undefined) {
      resolved.app_name = msg.app_name;
    }
    else {
      resolved.app_name = ''
    }

    if (msg.step !== undefined) {
      resolved.step = msg.step;
    }
    else {
      resolved.step = ''
    }

    if (msg.category !== undefined) {
      resolved.category = promobot_msgs.msg.ID.Resolve(msg.category)
    }
    else {
      resolved.category = new promobot_msgs.msg.ID()
    }

    if (msg.use_general !== undefined) {
      resolved.use_general = msg.use_general;
    }
    else {
      resolved.use_general = false
    }

    if (msg.use_biometry !== undefined) {
      resolved.use_biometry = msg.use_biometry;
    }
    else {
      resolved.use_biometry = false
    }

    if (msg.user_uuid !== undefined) {
      resolved.user_uuid = msg.user_uuid;
    }
    else {
      resolved.user_uuid = ''
    }

    if (msg.info !== undefined) {
      resolved.info = promobot_msgs.msg.Face.Resolve(msg.info)
    }
    else {
      resolved.info = new promobot_msgs.msg.Face()
    }

    return resolved;
    }
};

class GetAppReplicaResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.replica = null;
    }
    else {
      if (initObj.hasOwnProperty('replica')) {
        this.replica = initObj.replica
      }
      else {
        this.replica = new promobot_msgs.msg.Replica();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAppReplicaResponse
    // Serialize message field [replica]
    bufferOffset = promobot_msgs.msg.Replica.serialize(obj.replica, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAppReplicaResponse
    let len;
    let data = new GetAppReplicaResponse(null);
    // Deserialize message field [replica]
    data.replica = promobot_msgs.msg.Replica.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += promobot_msgs.msg.Replica.getMessageSize(object.replica);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/GetAppReplicaResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd5aa5f91a5533bbf83d5e7a4250520ab';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/Replica replica
    
    
    ================================================================================
    MSG: promobot_msgs/Replica
    promobot_msgs/ID id
    promobot_msgs/ID category
    promobot_msgs/ID anchor
    string text
    string screentext
    string url
    string action
    uint8 animation
    uint16 type
    bool interrupt_by_hark
    
    ================================================================================
    MSG: promobot_msgs/ID
    uint32 id
    string uuid
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAppReplicaResponse(null);
    if (msg.replica !== undefined) {
      resolved.replica = promobot_msgs.msg.Replica.Resolve(msg.replica)
    }
    else {
      resolved.replica = new promobot_msgs.msg.Replica()
    }

    return resolved;
    }
};

module.exports = {
  Request: GetAppReplicaRequest,
  Response: GetAppReplicaResponse,
  md5sum() { return '06536763381b08a6909e2e0d1da44fa9'; },
  datatype() { return 'promobot_srvs/GetAppReplica'; }
};

// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Ranges {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.f_a = null;
      this.f_b = null;
      this.f_c = null;
      this.f_d = null;
      this.r_a = null;
      this.r_b = null;
      this.r_c = null;
      this.r_d = null;
      this.t_0 = null;
      this.t_1 = null;
      this.t_2 = null;
      this.t_3 = null;
    }
    else {
      if (initObj.hasOwnProperty('f_a')) {
        this.f_a = initObj.f_a
      }
      else {
        this.f_a = 0;
      }
      if (initObj.hasOwnProperty('f_b')) {
        this.f_b = initObj.f_b
      }
      else {
        this.f_b = 0;
      }
      if (initObj.hasOwnProperty('f_c')) {
        this.f_c = initObj.f_c
      }
      else {
        this.f_c = 0;
      }
      if (initObj.hasOwnProperty('f_d')) {
        this.f_d = initObj.f_d
      }
      else {
        this.f_d = 0;
      }
      if (initObj.hasOwnProperty('r_a')) {
        this.r_a = initObj.r_a
      }
      else {
        this.r_a = 0;
      }
      if (initObj.hasOwnProperty('r_b')) {
        this.r_b = initObj.r_b
      }
      else {
        this.r_b = 0;
      }
      if (initObj.hasOwnProperty('r_c')) {
        this.r_c = initObj.r_c
      }
      else {
        this.r_c = 0;
      }
      if (initObj.hasOwnProperty('r_d')) {
        this.r_d = initObj.r_d
      }
      else {
        this.r_d = 0;
      }
      if (initObj.hasOwnProperty('t_0')) {
        this.t_0 = initObj.t_0
      }
      else {
        this.t_0 = 0;
      }
      if (initObj.hasOwnProperty('t_1')) {
        this.t_1 = initObj.t_1
      }
      else {
        this.t_1 = 0;
      }
      if (initObj.hasOwnProperty('t_2')) {
        this.t_2 = initObj.t_2
      }
      else {
        this.t_2 = 0;
      }
      if (initObj.hasOwnProperty('t_3')) {
        this.t_3 = initObj.t_3
      }
      else {
        this.t_3 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Ranges
    // Serialize message field [f_a]
    bufferOffset = _serializer.uint8(obj.f_a, buffer, bufferOffset);
    // Serialize message field [f_b]
    bufferOffset = _serializer.uint8(obj.f_b, buffer, bufferOffset);
    // Serialize message field [f_c]
    bufferOffset = _serializer.uint8(obj.f_c, buffer, bufferOffset);
    // Serialize message field [f_d]
    bufferOffset = _serializer.uint8(obj.f_d, buffer, bufferOffset);
    // Serialize message field [r_a]
    bufferOffset = _serializer.uint8(obj.r_a, buffer, bufferOffset);
    // Serialize message field [r_b]
    bufferOffset = _serializer.uint8(obj.r_b, buffer, bufferOffset);
    // Serialize message field [r_c]
    bufferOffset = _serializer.uint8(obj.r_c, buffer, bufferOffset);
    // Serialize message field [r_d]
    bufferOffset = _serializer.uint8(obj.r_d, buffer, bufferOffset);
    // Serialize message field [t_0]
    bufferOffset = _serializer.uint8(obj.t_0, buffer, bufferOffset);
    // Serialize message field [t_1]
    bufferOffset = _serializer.uint8(obj.t_1, buffer, bufferOffset);
    // Serialize message field [t_2]
    bufferOffset = _serializer.uint8(obj.t_2, buffer, bufferOffset);
    // Serialize message field [t_3]
    bufferOffset = _serializer.uint8(obj.t_3, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Ranges
    let len;
    let data = new Ranges(null);
    // Deserialize message field [f_a]
    data.f_a = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f_b]
    data.f_b = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f_c]
    data.f_c = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [f_d]
    data.f_d = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [r_a]
    data.r_a = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [r_b]
    data.r_b = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [r_c]
    data.r_c = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [r_d]
    data.r_d = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [t_0]
    data.t_0 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [t_1]
    data.t_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [t_2]
    data.t_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [t_3]
    data.t_3 = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Ranges';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06e2aaaa82118474505b47f99275c68a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 f_a
    uint8 f_b
    uint8 f_c
    uint8 f_d
    uint8 r_a
    uint8 r_b
    uint8 r_c
    uint8 r_d
    uint8 t_0
    uint8 t_1
    uint8 t_2
    uint8 t_3
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Ranges(null);
    if (msg.f_a !== undefined) {
      resolved.f_a = msg.f_a;
    }
    else {
      resolved.f_a = 0
    }

    if (msg.f_b !== undefined) {
      resolved.f_b = msg.f_b;
    }
    else {
      resolved.f_b = 0
    }

    if (msg.f_c !== undefined) {
      resolved.f_c = msg.f_c;
    }
    else {
      resolved.f_c = 0
    }

    if (msg.f_d !== undefined) {
      resolved.f_d = msg.f_d;
    }
    else {
      resolved.f_d = 0
    }

    if (msg.r_a !== undefined) {
      resolved.r_a = msg.r_a;
    }
    else {
      resolved.r_a = 0
    }

    if (msg.r_b !== undefined) {
      resolved.r_b = msg.r_b;
    }
    else {
      resolved.r_b = 0
    }

    if (msg.r_c !== undefined) {
      resolved.r_c = msg.r_c;
    }
    else {
      resolved.r_c = 0
    }

    if (msg.r_d !== undefined) {
      resolved.r_d = msg.r_d;
    }
    else {
      resolved.r_d = 0
    }

    if (msg.t_0 !== undefined) {
      resolved.t_0 = msg.t_0;
    }
    else {
      resolved.t_0 = 0
    }

    if (msg.t_1 !== undefined) {
      resolved.t_1 = msg.t_1;
    }
    else {
      resolved.t_1 = 0
    }

    if (msg.t_2 !== undefined) {
      resolved.t_2 = msg.t_2;
    }
    else {
      resolved.t_2 = 0
    }

    if (msg.t_3 !== undefined) {
      resolved.t_3 = msg.t_3;
    }
    else {
      resolved.t_3 = 0
    }

    return resolved;
    }
};

module.exports = Ranges;

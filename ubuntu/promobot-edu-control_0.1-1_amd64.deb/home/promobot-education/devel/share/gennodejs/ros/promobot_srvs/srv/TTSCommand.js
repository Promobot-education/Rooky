// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TTSCommandRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.text = null;
      this.terminate = null;
    }
    else {
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('terminate')) {
        this.terminate = initObj.terminate
      }
      else {
        this.terminate = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSCommandRequest
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [terminate]
    bufferOffset = _serializer.bool(obj.terminate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSCommandRequest
    let len;
    let data = new TTSCommandRequest(null);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [terminate]
    data.terminate = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.text.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/TTSCommandRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9095f3eee66c77c479251077e69fef7e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string text
    bool terminate
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSCommandRequest(null);
    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.terminate !== undefined) {
      resolved.terminate = msg.terminate;
    }
    else {
      resolved.terminate = false
    }

    return resolved;
    }
};

class TTSCommandResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.uuid = null;
    }
    else {
      if (initObj.hasOwnProperty('uuid')) {
        this.uuid = initObj.uuid
      }
      else {
        this.uuid = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSCommandResponse
    // Serialize message field [uuid]
    bufferOffset = _serializer.string(obj.uuid, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSCommandResponse
    let len;
    let data = new TTSCommandResponse(null);
    // Deserialize message field [uuid]
    data.uuid = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.uuid.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/TTSCommandResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '18ad0215778d252d8f14959901273e8d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string uuid
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSCommandResponse(null);
    if (msg.uuid !== undefined) {
      resolved.uuid = msg.uuid;
    }
    else {
      resolved.uuid = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TTSCommandRequest,
  Response: TTSCommandResponse,
  md5sum() { return 'f93438e4d13d0f684614297f05df0e39'; },
  datatype() { return 'promobot_srvs/TTSCommand'; }
};

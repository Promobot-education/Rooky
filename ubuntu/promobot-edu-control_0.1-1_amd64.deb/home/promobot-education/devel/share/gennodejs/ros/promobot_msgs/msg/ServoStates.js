// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ServoState = require('./ServoState.js');

//-----------------------------------------------------------

class ServoStates {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.states = null;
    }
    else {
      if (initObj.hasOwnProperty('states')) {
        this.states = initObj.states
      }
      else {
        this.states = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ServoStates
    // Serialize message field [states]
    // Serialize the length for message field [states]
    bufferOffset = _serializer.uint32(obj.states.length, buffer, bufferOffset);
    obj.states.forEach((val) => {
      bufferOffset = ServoState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ServoStates
    let len;
    let data = new ServoStates(null);
    // Deserialize message field [states]
    // Deserialize array length for message field [states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.states[i] = ServoState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.states.forEach((val) => {
      length += ServoState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/ServoStates';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '71c2bdf613842fa825cd448db8c688e7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ServoState[] states
    
    ================================================================================
    MSG: promobot_msgs/ServoState
    int32 id 		# ID сервы
    string name             # Имя сервы
    uint16 command		# Регистр команд
    bool torque        	# Разрешение работы двигателя
    int32 setPoint      	# Установка задачи
    uint16 fault_code	# Регистр ошибок
    string fault_code_str	# Регистр ошибок строка
    int32 encoderValue	# Значение енкодера
    int32 position		# Положение оси
    int32 velocity		# Скорость
    int32 motorCurrent	# Ток на двигателе
    HallSensors sensors	# Датчики крайних положений
    
    ================================================================================
    MSG: promobot_msgs/HallSensors
    bool  	leftSensor	# Левый датчик крайнего положения
    bool  	rightSensor	# Правый датчик крайнего положения
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ServoStates(null);
    if (msg.states !== undefined) {
      resolved.states = new Array(msg.states.length);
      for (let i = 0; i < resolved.states.length; ++i) {
        resolved.states[i] = ServoState.Resolve(msg.states[i]);
      }
    }
    else {
      resolved.states = []
    }

    return resolved;
    }
};

module.exports = ServoStates;

// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Power {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.voltage_33 = null;
      this.voltage_24 = null;
      this.voltage_16 = null;
      this.voltage_12 = null;
      this.voltage_5 = null;
      this.splitter_24 = null;
      this.splitter_16 = null;
      this.splitter_12 = null;
      this.current_33 = null;
      this.current_24 = null;
      this.current_16 = null;
      this.current_12 = null;
      this.current_5 = null;
      this.current_kinect = null;
      this.current_display = null;
      this.current_sound = null;
      this.current_terminal = null;
      this.current_photo_printer = null;
      this.current_servo = null;
      this.current_nuc = null;
      this.current_bill_printer = null;
    }
    else {
      if (initObj.hasOwnProperty('voltage_33')) {
        this.voltage_33 = initObj.voltage_33
      }
      else {
        this.voltage_33 = 0.0;
      }
      if (initObj.hasOwnProperty('voltage_24')) {
        this.voltage_24 = initObj.voltage_24
      }
      else {
        this.voltage_24 = 0.0;
      }
      if (initObj.hasOwnProperty('voltage_16')) {
        this.voltage_16 = initObj.voltage_16
      }
      else {
        this.voltage_16 = 0.0;
      }
      if (initObj.hasOwnProperty('voltage_12')) {
        this.voltage_12 = initObj.voltage_12
      }
      else {
        this.voltage_12 = 0.0;
      }
      if (initObj.hasOwnProperty('voltage_5')) {
        this.voltage_5 = initObj.voltage_5
      }
      else {
        this.voltage_5 = 0.0;
      }
      if (initObj.hasOwnProperty('splitter_24')) {
        this.splitter_24 = initObj.splitter_24
      }
      else {
        this.splitter_24 = false;
      }
      if (initObj.hasOwnProperty('splitter_16')) {
        this.splitter_16 = initObj.splitter_16
      }
      else {
        this.splitter_16 = false;
      }
      if (initObj.hasOwnProperty('splitter_12')) {
        this.splitter_12 = initObj.splitter_12
      }
      else {
        this.splitter_12 = false;
      }
      if (initObj.hasOwnProperty('current_33')) {
        this.current_33 = initObj.current_33
      }
      else {
        this.current_33 = 0.0;
      }
      if (initObj.hasOwnProperty('current_24')) {
        this.current_24 = initObj.current_24
      }
      else {
        this.current_24 = 0.0;
      }
      if (initObj.hasOwnProperty('current_16')) {
        this.current_16 = initObj.current_16
      }
      else {
        this.current_16 = 0.0;
      }
      if (initObj.hasOwnProperty('current_12')) {
        this.current_12 = initObj.current_12
      }
      else {
        this.current_12 = 0.0;
      }
      if (initObj.hasOwnProperty('current_5')) {
        this.current_5 = initObj.current_5
      }
      else {
        this.current_5 = 0.0;
      }
      if (initObj.hasOwnProperty('current_kinect')) {
        this.current_kinect = initObj.current_kinect
      }
      else {
        this.current_kinect = 0.0;
      }
      if (initObj.hasOwnProperty('current_display')) {
        this.current_display = initObj.current_display
      }
      else {
        this.current_display = 0.0;
      }
      if (initObj.hasOwnProperty('current_sound')) {
        this.current_sound = initObj.current_sound
      }
      else {
        this.current_sound = 0.0;
      }
      if (initObj.hasOwnProperty('current_terminal')) {
        this.current_terminal = initObj.current_terminal
      }
      else {
        this.current_terminal = 0.0;
      }
      if (initObj.hasOwnProperty('current_photo_printer')) {
        this.current_photo_printer = initObj.current_photo_printer
      }
      else {
        this.current_photo_printer = 0.0;
      }
      if (initObj.hasOwnProperty('current_servo')) {
        this.current_servo = initObj.current_servo
      }
      else {
        this.current_servo = 0.0;
      }
      if (initObj.hasOwnProperty('current_nuc')) {
        this.current_nuc = initObj.current_nuc
      }
      else {
        this.current_nuc = 0.0;
      }
      if (initObj.hasOwnProperty('current_bill_printer')) {
        this.current_bill_printer = initObj.current_bill_printer
      }
      else {
        this.current_bill_printer = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Power
    // Serialize message field [voltage_33]
    bufferOffset = _serializer.float32(obj.voltage_33, buffer, bufferOffset);
    // Serialize message field [voltage_24]
    bufferOffset = _serializer.float32(obj.voltage_24, buffer, bufferOffset);
    // Serialize message field [voltage_16]
    bufferOffset = _serializer.float32(obj.voltage_16, buffer, bufferOffset);
    // Serialize message field [voltage_12]
    bufferOffset = _serializer.float32(obj.voltage_12, buffer, bufferOffset);
    // Serialize message field [voltage_5]
    bufferOffset = _serializer.float32(obj.voltage_5, buffer, bufferOffset);
    // Serialize message field [splitter_24]
    bufferOffset = _serializer.bool(obj.splitter_24, buffer, bufferOffset);
    // Serialize message field [splitter_16]
    bufferOffset = _serializer.bool(obj.splitter_16, buffer, bufferOffset);
    // Serialize message field [splitter_12]
    bufferOffset = _serializer.bool(obj.splitter_12, buffer, bufferOffset);
    // Serialize message field [current_33]
    bufferOffset = _serializer.float32(obj.current_33, buffer, bufferOffset);
    // Serialize message field [current_24]
    bufferOffset = _serializer.float32(obj.current_24, buffer, bufferOffset);
    // Serialize message field [current_16]
    bufferOffset = _serializer.float32(obj.current_16, buffer, bufferOffset);
    // Serialize message field [current_12]
    bufferOffset = _serializer.float32(obj.current_12, buffer, bufferOffset);
    // Serialize message field [current_5]
    bufferOffset = _serializer.float32(obj.current_5, buffer, bufferOffset);
    // Serialize message field [current_kinect]
    bufferOffset = _serializer.float32(obj.current_kinect, buffer, bufferOffset);
    // Serialize message field [current_display]
    bufferOffset = _serializer.float32(obj.current_display, buffer, bufferOffset);
    // Serialize message field [current_sound]
    bufferOffset = _serializer.float32(obj.current_sound, buffer, bufferOffset);
    // Serialize message field [current_terminal]
    bufferOffset = _serializer.float32(obj.current_terminal, buffer, bufferOffset);
    // Serialize message field [current_photo_printer]
    bufferOffset = _serializer.float32(obj.current_photo_printer, buffer, bufferOffset);
    // Serialize message field [current_servo]
    bufferOffset = _serializer.float32(obj.current_servo, buffer, bufferOffset);
    // Serialize message field [current_nuc]
    bufferOffset = _serializer.float32(obj.current_nuc, buffer, bufferOffset);
    // Serialize message field [current_bill_printer]
    bufferOffset = _serializer.float32(obj.current_bill_printer, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Power
    let len;
    let data = new Power(null);
    // Deserialize message field [voltage_33]
    data.voltage_33 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [voltage_24]
    data.voltage_24 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [voltage_16]
    data.voltage_16 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [voltage_12]
    data.voltage_12 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [voltage_5]
    data.voltage_5 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [splitter_24]
    data.splitter_24 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [splitter_16]
    data.splitter_16 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [splitter_12]
    data.splitter_12 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [current_33]
    data.current_33 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_24]
    data.current_24 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_16]
    data.current_16 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_12]
    data.current_12 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_5]
    data.current_5 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_kinect]
    data.current_kinect = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_display]
    data.current_display = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_sound]
    data.current_sound = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_terminal]
    data.current_terminal = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_photo_printer]
    data.current_photo_printer = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_servo]
    data.current_servo = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_nuc]
    data.current_nuc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [current_bill_printer]
    data.current_bill_printer = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 75;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Power';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1d21869e64fa72c2633ba63815f7532c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 voltage_33
    float32 voltage_24
    float32 voltage_16
    float32 voltage_12
    float32 voltage_5
    bool splitter_24
    bool splitter_16
    bool splitter_12
    float32 current_33
    float32 current_24
    float32 current_16
    float32 current_12
    float32 current_5
    float32 current_kinect
    float32 current_display
    float32 current_sound
    float32 current_terminal
    float32 current_photo_printer
    float32 current_servo
    float32 current_nuc
    float32 current_bill_printer
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Power(null);
    if (msg.voltage_33 !== undefined) {
      resolved.voltage_33 = msg.voltage_33;
    }
    else {
      resolved.voltage_33 = 0.0
    }

    if (msg.voltage_24 !== undefined) {
      resolved.voltage_24 = msg.voltage_24;
    }
    else {
      resolved.voltage_24 = 0.0
    }

    if (msg.voltage_16 !== undefined) {
      resolved.voltage_16 = msg.voltage_16;
    }
    else {
      resolved.voltage_16 = 0.0
    }

    if (msg.voltage_12 !== undefined) {
      resolved.voltage_12 = msg.voltage_12;
    }
    else {
      resolved.voltage_12 = 0.0
    }

    if (msg.voltage_5 !== undefined) {
      resolved.voltage_5 = msg.voltage_5;
    }
    else {
      resolved.voltage_5 = 0.0
    }

    if (msg.splitter_24 !== undefined) {
      resolved.splitter_24 = msg.splitter_24;
    }
    else {
      resolved.splitter_24 = false
    }

    if (msg.splitter_16 !== undefined) {
      resolved.splitter_16 = msg.splitter_16;
    }
    else {
      resolved.splitter_16 = false
    }

    if (msg.splitter_12 !== undefined) {
      resolved.splitter_12 = msg.splitter_12;
    }
    else {
      resolved.splitter_12 = false
    }

    if (msg.current_33 !== undefined) {
      resolved.current_33 = msg.current_33;
    }
    else {
      resolved.current_33 = 0.0
    }

    if (msg.current_24 !== undefined) {
      resolved.current_24 = msg.current_24;
    }
    else {
      resolved.current_24 = 0.0
    }

    if (msg.current_16 !== undefined) {
      resolved.current_16 = msg.current_16;
    }
    else {
      resolved.current_16 = 0.0
    }

    if (msg.current_12 !== undefined) {
      resolved.current_12 = msg.current_12;
    }
    else {
      resolved.current_12 = 0.0
    }

    if (msg.current_5 !== undefined) {
      resolved.current_5 = msg.current_5;
    }
    else {
      resolved.current_5 = 0.0
    }

    if (msg.current_kinect !== undefined) {
      resolved.current_kinect = msg.current_kinect;
    }
    else {
      resolved.current_kinect = 0.0
    }

    if (msg.current_display !== undefined) {
      resolved.current_display = msg.current_display;
    }
    else {
      resolved.current_display = 0.0
    }

    if (msg.current_sound !== undefined) {
      resolved.current_sound = msg.current_sound;
    }
    else {
      resolved.current_sound = 0.0
    }

    if (msg.current_terminal !== undefined) {
      resolved.current_terminal = msg.current_terminal;
    }
    else {
      resolved.current_terminal = 0.0
    }

    if (msg.current_photo_printer !== undefined) {
      resolved.current_photo_printer = msg.current_photo_printer;
    }
    else {
      resolved.current_photo_printer = 0.0
    }

    if (msg.current_servo !== undefined) {
      resolved.current_servo = msg.current_servo;
    }
    else {
      resolved.current_servo = 0.0
    }

    if (msg.current_nuc !== undefined) {
      resolved.current_nuc = msg.current_nuc;
    }
    else {
      resolved.current_nuc = 0.0
    }

    if (msg.current_bill_printer !== undefined) {
      resolved.current_bill_printer = msg.current_bill_printer;
    }
    else {
      resolved.current_bill_printer = 0.0
    }

    return resolved;
    }
};

module.exports = Power;

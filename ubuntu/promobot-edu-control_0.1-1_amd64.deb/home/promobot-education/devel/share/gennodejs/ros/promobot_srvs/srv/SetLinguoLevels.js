// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let promobot_msgs = _finder('promobot_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetLinguoLevelsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.levels = null;
      this.ignore_errors = null;
    }
    else {
      if (initObj.hasOwnProperty('levels')) {
        this.levels = initObj.levels
      }
      else {
        this.levels = [];
      }
      if (initObj.hasOwnProperty('ignore_errors')) {
        this.ignore_errors = initObj.ignore_errors
      }
      else {
        this.ignore_errors = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetLinguoLevelsRequest
    // Serialize message field [levels]
    // Serialize the length for message field [levels]
    bufferOffset = _serializer.uint32(obj.levels.length, buffer, bufferOffset);
    obj.levels.forEach((val) => {
      bufferOffset = promobot_msgs.msg.LinguoLevel.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [ignore_errors]
    bufferOffset = _serializer.bool(obj.ignore_errors, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetLinguoLevelsRequest
    let len;
    let data = new SetLinguoLevelsRequest(null);
    // Deserialize message field [levels]
    // Deserialize array length for message field [levels]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.levels = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.levels[i] = promobot_msgs.msg.LinguoLevel.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [ignore_errors]
    data.ignore_errors = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.levels.forEach((val) => {
      length += promobot_msgs.msg.LinguoLevel.getMessageSize(val);
    });
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/SetLinguoLevelsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4ba1fd5909f5187246cea6f24d7d59ba';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/LinguoLevel[] levels
    bool ignore_errors
    
    ================================================================================
    MSG: promobot_msgs/LinguoLevel
    uint16 id
    string name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetLinguoLevelsRequest(null);
    if (msg.levels !== undefined) {
      resolved.levels = new Array(msg.levels.length);
      for (let i = 0; i < resolved.levels.length; ++i) {
        resolved.levels[i] = promobot_msgs.msg.LinguoLevel.Resolve(msg.levels[i]);
      }
    }
    else {
      resolved.levels = []
    }

    if (msg.ignore_errors !== undefined) {
      resolved.ignore_errors = msg.ignore_errors;
    }
    else {
      resolved.ignore_errors = false
    }

    return resolved;
    }
};

class SetLinguoLevelsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ok = null;
    }
    else {
      if (initObj.hasOwnProperty('ok')) {
        this.ok = initObj.ok
      }
      else {
        this.ok = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetLinguoLevelsResponse
    // Serialize message field [ok]
    bufferOffset = _serializer.bool(obj.ok, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetLinguoLevelsResponse
    let len;
    let data = new SetLinguoLevelsResponse(null);
    // Deserialize message field [ok]
    data.ok = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/SetLinguoLevelsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6f6da3883749771fac40d6deb24a8c02';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool ok
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetLinguoLevelsResponse(null);
    if (msg.ok !== undefined) {
      resolved.ok = msg.ok;
    }
    else {
      resolved.ok = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetLinguoLevelsRequest,
  Response: SetLinguoLevelsResponse,
  md5sum() { return 'edf808f2a0ee0e8be378a9a3fc4ac281'; },
  datatype() { return 'promobot_srvs/SetLinguoLevels'; }
};

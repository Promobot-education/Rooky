// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class JoystickRumbleRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.low_frequency_rumble = null;
      this.high_frequency_rumble = null;
      this.duration_ms = null;
    }
    else {
      if (initObj.hasOwnProperty('low_frequency_rumble')) {
        this.low_frequency_rumble = initObj.low_frequency_rumble
      }
      else {
        this.low_frequency_rumble = 0;
      }
      if (initObj.hasOwnProperty('high_frequency_rumble')) {
        this.high_frequency_rumble = initObj.high_frequency_rumble
      }
      else {
        this.high_frequency_rumble = 0;
      }
      if (initObj.hasOwnProperty('duration_ms')) {
        this.duration_ms = initObj.duration_ms
      }
      else {
        this.duration_ms = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type JoystickRumbleRequest
    // Serialize message field [low_frequency_rumble]
    bufferOffset = _serializer.uint16(obj.low_frequency_rumble, buffer, bufferOffset);
    // Serialize message field [high_frequency_rumble]
    bufferOffset = _serializer.uint16(obj.high_frequency_rumble, buffer, bufferOffset);
    // Serialize message field [duration_ms]
    bufferOffset = _serializer.uint32(obj.duration_ms, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type JoystickRumbleRequest
    let len;
    let data = new JoystickRumbleRequest(null);
    // Deserialize message field [low_frequency_rumble]
    data.low_frequency_rumble = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [high_frequency_rumble]
    data.high_frequency_rumble = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [duration_ms]
    data.duration_ms = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/JoystickRumbleRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8ea7fc2db4b066c2c4f2b6f51b6b64f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 low_frequency_rumble
    uint16 high_frequency_rumble
    uint32 duration_ms
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new JoystickRumbleRequest(null);
    if (msg.low_frequency_rumble !== undefined) {
      resolved.low_frequency_rumble = msg.low_frequency_rumble;
    }
    else {
      resolved.low_frequency_rumble = 0
    }

    if (msg.high_frequency_rumble !== undefined) {
      resolved.high_frequency_rumble = msg.high_frequency_rumble;
    }
    else {
      resolved.high_frequency_rumble = 0
    }

    if (msg.duration_ms !== undefined) {
      resolved.duration_ms = msg.duration_ms;
    }
    else {
      resolved.duration_ms = 0
    }

    return resolved;
    }
};

class JoystickRumbleResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ret = null;
    }
    else {
      if (initObj.hasOwnProperty('ret')) {
        this.ret = initObj.ret
      }
      else {
        this.ret = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type JoystickRumbleResponse
    // Serialize message field [ret]
    bufferOffset = _serializer.int16(obj.ret, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type JoystickRumbleResponse
    let len;
    let data = new JoystickRumbleResponse(null);
    // Deserialize message field [ret]
    data.ret = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/JoystickRumbleResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '16207eaaf5c714348263d9afc66bbfea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 ret
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new JoystickRumbleResponse(null);
    if (msg.ret !== undefined) {
      resolved.ret = msg.ret;
    }
    else {
      resolved.ret = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: JoystickRumbleRequest,
  Response: JoystickRumbleResponse,
  md5sum() { return '2e00629975af1cf081d9ab47ae49172a'; },
  datatype() { return 'promobot_srvs/JoystickRumble'; }
};

// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SipCallWithWav {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.phone_number = null;
      this.wav_path = null;
    }
    else {
      if (initObj.hasOwnProperty('phone_number')) {
        this.phone_number = initObj.phone_number
      }
      else {
        this.phone_number = '';
      }
      if (initObj.hasOwnProperty('wav_path')) {
        this.wav_path = initObj.wav_path
      }
      else {
        this.wav_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SipCallWithWav
    // Serialize message field [phone_number]
    bufferOffset = _serializer.string(obj.phone_number, buffer, bufferOffset);
    // Serialize message field [wav_path]
    bufferOffset = _serializer.string(obj.wav_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SipCallWithWav
    let len;
    let data = new SipCallWithWav(null);
    // Deserialize message field [phone_number]
    data.phone_number = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [wav_path]
    data.wav_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.phone_number.length;
    length += object.wav_path.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/SipCallWithWav';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cd8f3abfef3c7b4cf5f072ef055def78';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string phone_number
    string wav_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SipCallWithWav(null);
    if (msg.phone_number !== undefined) {
      resolved.phone_number = msg.phone_number;
    }
    else {
      resolved.phone_number = ''
    }

    if (msg.wav_path !== undefined) {
      resolved.wav_path = msg.wav_path;
    }
    else {
      resolved.wav_path = ''
    }

    return resolved;
    }
};

module.exports = SipCallWithWav;

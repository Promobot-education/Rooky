// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FaceAddStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.step = null;
      this.max = null;
      this.cur = null;
    }
    else {
      if (initObj.hasOwnProperty('step')) {
        this.step = initObj.step
      }
      else {
        this.step = 0;
      }
      if (initObj.hasOwnProperty('max')) {
        this.max = initObj.max
      }
      else {
        this.max = 0;
      }
      if (initObj.hasOwnProperty('cur')) {
        this.cur = initObj.cur
      }
      else {
        this.cur = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FaceAddStatus
    // Serialize message field [step]
    bufferOffset = _serializer.uint8(obj.step, buffer, bufferOffset);
    // Serialize message field [max]
    bufferOffset = _serializer.uint8(obj.max, buffer, bufferOffset);
    // Serialize message field [cur]
    bufferOffset = _serializer.uint8(obj.cur, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FaceAddStatus
    let len;
    let data = new FaceAddStatus(null);
    // Deserialize message field [step]
    data.step = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [max]
    data.max = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [cur]
    data.cur = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/FaceAddStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '44999001d05fa9259337eb366f00408a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 step
    uint8 max
    uint8 cur
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FaceAddStatus(null);
    if (msg.step !== undefined) {
      resolved.step = msg.step;
    }
    else {
      resolved.step = 0
    }

    if (msg.max !== undefined) {
      resolved.max = msg.max;
    }
    else {
      resolved.max = 0
    }

    if (msg.cur !== undefined) {
      resolved.cur = msg.cur;
    }
    else {
      resolved.cur = 0
    }

    return resolved;
    }
};

module.exports = FaceAddStatus;

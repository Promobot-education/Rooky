// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let HallSensors = require('./HallSensors.js');

//-----------------------------------------------------------

class ServoState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.command = null;
      this.torque = null;
      this.setPoint = null;
      this.fault_code = null;
      this.fault_code_str = null;
      this.encoderValue = null;
      this.position = null;
      this.velocity = null;
      this.motorCurrent = null;
      this.sensors = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('command')) {
        this.command = initObj.command
      }
      else {
        this.command = 0;
      }
      if (initObj.hasOwnProperty('torque')) {
        this.torque = initObj.torque
      }
      else {
        this.torque = false;
      }
      if (initObj.hasOwnProperty('setPoint')) {
        this.setPoint = initObj.setPoint
      }
      else {
        this.setPoint = 0;
      }
      if (initObj.hasOwnProperty('fault_code')) {
        this.fault_code = initObj.fault_code
      }
      else {
        this.fault_code = 0;
      }
      if (initObj.hasOwnProperty('fault_code_str')) {
        this.fault_code_str = initObj.fault_code_str
      }
      else {
        this.fault_code_str = '';
      }
      if (initObj.hasOwnProperty('encoderValue')) {
        this.encoderValue = initObj.encoderValue
      }
      else {
        this.encoderValue = 0;
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = 0;
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = 0;
      }
      if (initObj.hasOwnProperty('motorCurrent')) {
        this.motorCurrent = initObj.motorCurrent
      }
      else {
        this.motorCurrent = 0;
      }
      if (initObj.hasOwnProperty('sensors')) {
        this.sensors = initObj.sensors
      }
      else {
        this.sensors = new HallSensors();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ServoState
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [command]
    bufferOffset = _serializer.uint16(obj.command, buffer, bufferOffset);
    // Serialize message field [torque]
    bufferOffset = _serializer.bool(obj.torque, buffer, bufferOffset);
    // Serialize message field [setPoint]
    bufferOffset = _serializer.int32(obj.setPoint, buffer, bufferOffset);
    // Serialize message field [fault_code]
    bufferOffset = _serializer.uint16(obj.fault_code, buffer, bufferOffset);
    // Serialize message field [fault_code_str]
    bufferOffset = _serializer.string(obj.fault_code_str, buffer, bufferOffset);
    // Serialize message field [encoderValue]
    bufferOffset = _serializer.int32(obj.encoderValue, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = _serializer.int32(obj.position, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = _serializer.int32(obj.velocity, buffer, bufferOffset);
    // Serialize message field [motorCurrent]
    bufferOffset = _serializer.int32(obj.motorCurrent, buffer, bufferOffset);
    // Serialize message field [sensors]
    bufferOffset = HallSensors.serialize(obj.sensors, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ServoState
    let len;
    let data = new ServoState(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [command]
    data.command = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [torque]
    data.torque = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [setPoint]
    data.setPoint = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [fault_code]
    data.fault_code = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [fault_code_str]
    data.fault_code_str = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [encoderValue]
    data.encoderValue = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [motorCurrent]
    data.motorCurrent = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [sensors]
    data.sensors = HallSensors.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.fault_code_str.length;
    return length + 39;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/ServoState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b57b780e9eaaa9bd894373eb952bf8d9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 id 		# ID сервы
    string name             # Имя сервы
    uint16 command		# Регистр команд
    bool torque        	# Разрешение работы двигателя
    int32 setPoint      	# Установка задачи
    uint16 fault_code	# Регистр ошибок
    string fault_code_str	# Регистр ошибок строка
    int32 encoderValue	# Значение енкодера
    int32 position		# Положение оси
    int32 velocity		# Скорость
    int32 motorCurrent	# Ток на двигателе
    HallSensors sensors	# Датчики крайних положений
    
    ================================================================================
    MSG: promobot_msgs/HallSensors
    bool  	leftSensor	# Левый датчик крайнего положения
    bool  	rightSensor	# Правый датчик крайнего положения
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ServoState(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.command !== undefined) {
      resolved.command = msg.command;
    }
    else {
      resolved.command = 0
    }

    if (msg.torque !== undefined) {
      resolved.torque = msg.torque;
    }
    else {
      resolved.torque = false
    }

    if (msg.setPoint !== undefined) {
      resolved.setPoint = msg.setPoint;
    }
    else {
      resolved.setPoint = 0
    }

    if (msg.fault_code !== undefined) {
      resolved.fault_code = msg.fault_code;
    }
    else {
      resolved.fault_code = 0
    }

    if (msg.fault_code_str !== undefined) {
      resolved.fault_code_str = msg.fault_code_str;
    }
    else {
      resolved.fault_code_str = ''
    }

    if (msg.encoderValue !== undefined) {
      resolved.encoderValue = msg.encoderValue;
    }
    else {
      resolved.encoderValue = 0
    }

    if (msg.position !== undefined) {
      resolved.position = msg.position;
    }
    else {
      resolved.position = 0
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = 0
    }

    if (msg.motorCurrent !== undefined) {
      resolved.motorCurrent = msg.motorCurrent;
    }
    else {
      resolved.motorCurrent = 0
    }

    if (msg.sensors !== undefined) {
      resolved.sensors = HallSensors.Resolve(msg.sensors)
    }
    else {
      resolved.sensors = new HallSensors()
    }

    return resolved;
    }
};

module.exports = ServoState;

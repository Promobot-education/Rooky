// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Modbus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timeout = null;
      this.retries = null;
      this.moving_call = null;
      this.power_call = null;
      this.terminal_call = null;
      this.charger_call = null;
      this.power_splitter_call = null;
      this.hands_head_call = null;
      this.touch_right_call = null;
      this.touch_left_call = null;
      this.touch_head_call = null;
      this.moving_debug = null;
      this.power_debug = null;
      this.terminal_debug = null;
      this.charger_debug = null;
      this.power_splitter_debug = null;
      this.hands_head_debug = null;
      this.touch_right_debug = null;
      this.touch_left_debug = null;
      this.touch_head_debug = null;
      this.moving_errors = null;
      this.power_errors = null;
      this.terminal_errors = null;
      this.charger_errors = null;
      this.power_splitter_errors = null;
      this.hands_head_errors = null;
      this.touch_right_errors = null;
      this.touch_left_errors = null;
      this.touch_head_errors = null;
    }
    else {
      if (initObj.hasOwnProperty('timeout')) {
        this.timeout = initObj.timeout
      }
      else {
        this.timeout = '';
      }
      if (initObj.hasOwnProperty('retries')) {
        this.retries = initObj.retries
      }
      else {
        this.retries = 0;
      }
      if (initObj.hasOwnProperty('moving_call')) {
        this.moving_call = initObj.moving_call
      }
      else {
        this.moving_call = false;
      }
      if (initObj.hasOwnProperty('power_call')) {
        this.power_call = initObj.power_call
      }
      else {
        this.power_call = false;
      }
      if (initObj.hasOwnProperty('terminal_call')) {
        this.terminal_call = initObj.terminal_call
      }
      else {
        this.terminal_call = false;
      }
      if (initObj.hasOwnProperty('charger_call')) {
        this.charger_call = initObj.charger_call
      }
      else {
        this.charger_call = false;
      }
      if (initObj.hasOwnProperty('power_splitter_call')) {
        this.power_splitter_call = initObj.power_splitter_call
      }
      else {
        this.power_splitter_call = false;
      }
      if (initObj.hasOwnProperty('hands_head_call')) {
        this.hands_head_call = initObj.hands_head_call
      }
      else {
        this.hands_head_call = false;
      }
      if (initObj.hasOwnProperty('touch_right_call')) {
        this.touch_right_call = initObj.touch_right_call
      }
      else {
        this.touch_right_call = false;
      }
      if (initObj.hasOwnProperty('touch_left_call')) {
        this.touch_left_call = initObj.touch_left_call
      }
      else {
        this.touch_left_call = false;
      }
      if (initObj.hasOwnProperty('touch_head_call')) {
        this.touch_head_call = initObj.touch_head_call
      }
      else {
        this.touch_head_call = false;
      }
      if (initObj.hasOwnProperty('moving_debug')) {
        this.moving_debug = initObj.moving_debug
      }
      else {
        this.moving_debug = false;
      }
      if (initObj.hasOwnProperty('power_debug')) {
        this.power_debug = initObj.power_debug
      }
      else {
        this.power_debug = false;
      }
      if (initObj.hasOwnProperty('terminal_debug')) {
        this.terminal_debug = initObj.terminal_debug
      }
      else {
        this.terminal_debug = false;
      }
      if (initObj.hasOwnProperty('charger_debug')) {
        this.charger_debug = initObj.charger_debug
      }
      else {
        this.charger_debug = false;
      }
      if (initObj.hasOwnProperty('power_splitter_debug')) {
        this.power_splitter_debug = initObj.power_splitter_debug
      }
      else {
        this.power_splitter_debug = false;
      }
      if (initObj.hasOwnProperty('hands_head_debug')) {
        this.hands_head_debug = initObj.hands_head_debug
      }
      else {
        this.hands_head_debug = false;
      }
      if (initObj.hasOwnProperty('touch_right_debug')) {
        this.touch_right_debug = initObj.touch_right_debug
      }
      else {
        this.touch_right_debug = false;
      }
      if (initObj.hasOwnProperty('touch_left_debug')) {
        this.touch_left_debug = initObj.touch_left_debug
      }
      else {
        this.touch_left_debug = false;
      }
      if (initObj.hasOwnProperty('touch_head_debug')) {
        this.touch_head_debug = initObj.touch_head_debug
      }
      else {
        this.touch_head_debug = false;
      }
      if (initObj.hasOwnProperty('moving_errors')) {
        this.moving_errors = initObj.moving_errors
      }
      else {
        this.moving_errors = 0;
      }
      if (initObj.hasOwnProperty('power_errors')) {
        this.power_errors = initObj.power_errors
      }
      else {
        this.power_errors = 0;
      }
      if (initObj.hasOwnProperty('terminal_errors')) {
        this.terminal_errors = initObj.terminal_errors
      }
      else {
        this.terminal_errors = 0;
      }
      if (initObj.hasOwnProperty('charger_errors')) {
        this.charger_errors = initObj.charger_errors
      }
      else {
        this.charger_errors = 0;
      }
      if (initObj.hasOwnProperty('power_splitter_errors')) {
        this.power_splitter_errors = initObj.power_splitter_errors
      }
      else {
        this.power_splitter_errors = 0;
      }
      if (initObj.hasOwnProperty('hands_head_errors')) {
        this.hands_head_errors = initObj.hands_head_errors
      }
      else {
        this.hands_head_errors = 0;
      }
      if (initObj.hasOwnProperty('touch_right_errors')) {
        this.touch_right_errors = initObj.touch_right_errors
      }
      else {
        this.touch_right_errors = 0;
      }
      if (initObj.hasOwnProperty('touch_left_errors')) {
        this.touch_left_errors = initObj.touch_left_errors
      }
      else {
        this.touch_left_errors = 0;
      }
      if (initObj.hasOwnProperty('touch_head_errors')) {
        this.touch_head_errors = initObj.touch_head_errors
      }
      else {
        this.touch_head_errors = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Modbus
    // Serialize message field [timeout]
    bufferOffset = _serializer.string(obj.timeout, buffer, bufferOffset);
    // Serialize message field [retries]
    bufferOffset = _serializer.uint8(obj.retries, buffer, bufferOffset);
    // Serialize message field [moving_call]
    bufferOffset = _serializer.bool(obj.moving_call, buffer, bufferOffset);
    // Serialize message field [power_call]
    bufferOffset = _serializer.bool(obj.power_call, buffer, bufferOffset);
    // Serialize message field [terminal_call]
    bufferOffset = _serializer.bool(obj.terminal_call, buffer, bufferOffset);
    // Serialize message field [charger_call]
    bufferOffset = _serializer.bool(obj.charger_call, buffer, bufferOffset);
    // Serialize message field [power_splitter_call]
    bufferOffset = _serializer.bool(obj.power_splitter_call, buffer, bufferOffset);
    // Serialize message field [hands_head_call]
    bufferOffset = _serializer.bool(obj.hands_head_call, buffer, bufferOffset);
    // Serialize message field [touch_right_call]
    bufferOffset = _serializer.bool(obj.touch_right_call, buffer, bufferOffset);
    // Serialize message field [touch_left_call]
    bufferOffset = _serializer.bool(obj.touch_left_call, buffer, bufferOffset);
    // Serialize message field [touch_head_call]
    bufferOffset = _serializer.bool(obj.touch_head_call, buffer, bufferOffset);
    // Serialize message field [moving_debug]
    bufferOffset = _serializer.bool(obj.moving_debug, buffer, bufferOffset);
    // Serialize message field [power_debug]
    bufferOffset = _serializer.bool(obj.power_debug, buffer, bufferOffset);
    // Serialize message field [terminal_debug]
    bufferOffset = _serializer.bool(obj.terminal_debug, buffer, bufferOffset);
    // Serialize message field [charger_debug]
    bufferOffset = _serializer.bool(obj.charger_debug, buffer, bufferOffset);
    // Serialize message field [power_splitter_debug]
    bufferOffset = _serializer.bool(obj.power_splitter_debug, buffer, bufferOffset);
    // Serialize message field [hands_head_debug]
    bufferOffset = _serializer.bool(obj.hands_head_debug, buffer, bufferOffset);
    // Serialize message field [touch_right_debug]
    bufferOffset = _serializer.bool(obj.touch_right_debug, buffer, bufferOffset);
    // Serialize message field [touch_left_debug]
    bufferOffset = _serializer.bool(obj.touch_left_debug, buffer, bufferOffset);
    // Serialize message field [touch_head_debug]
    bufferOffset = _serializer.bool(obj.touch_head_debug, buffer, bufferOffset);
    // Serialize message field [moving_errors]
    bufferOffset = _serializer.uint32(obj.moving_errors, buffer, bufferOffset);
    // Serialize message field [power_errors]
    bufferOffset = _serializer.uint32(obj.power_errors, buffer, bufferOffset);
    // Serialize message field [terminal_errors]
    bufferOffset = _serializer.uint32(obj.terminal_errors, buffer, bufferOffset);
    // Serialize message field [charger_errors]
    bufferOffset = _serializer.uint32(obj.charger_errors, buffer, bufferOffset);
    // Serialize message field [power_splitter_errors]
    bufferOffset = _serializer.uint32(obj.power_splitter_errors, buffer, bufferOffset);
    // Serialize message field [hands_head_errors]
    bufferOffset = _serializer.uint32(obj.hands_head_errors, buffer, bufferOffset);
    // Serialize message field [touch_right_errors]
    bufferOffset = _serializer.uint32(obj.touch_right_errors, buffer, bufferOffset);
    // Serialize message field [touch_left_errors]
    bufferOffset = _serializer.uint32(obj.touch_left_errors, buffer, bufferOffset);
    // Serialize message field [touch_head_errors]
    bufferOffset = _serializer.uint32(obj.touch_head_errors, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Modbus
    let len;
    let data = new Modbus(null);
    // Deserialize message field [timeout]
    data.timeout = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [retries]
    data.retries = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [moving_call]
    data.moving_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [power_call]
    data.power_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [terminal_call]
    data.terminal_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [charger_call]
    data.charger_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [power_splitter_call]
    data.power_splitter_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hands_head_call]
    data.hands_head_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_right_call]
    data.touch_right_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_left_call]
    data.touch_left_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_head_call]
    data.touch_head_call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [moving_debug]
    data.moving_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [power_debug]
    data.power_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [terminal_debug]
    data.terminal_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [charger_debug]
    data.charger_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [power_splitter_debug]
    data.power_splitter_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hands_head_debug]
    data.hands_head_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_right_debug]
    data.touch_right_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_left_debug]
    data.touch_left_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [touch_head_debug]
    data.touch_head_debug = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [moving_errors]
    data.moving_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [power_errors]
    data.power_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [terminal_errors]
    data.terminal_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [charger_errors]
    data.charger_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [power_splitter_errors]
    data.power_splitter_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [hands_head_errors]
    data.hands_head_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [touch_right_errors]
    data.touch_right_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [touch_left_errors]
    data.touch_left_errors = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [touch_head_errors]
    data.touch_head_errors = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.timeout.length;
    return length + 59;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Modbus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '57f3fad23f0d5d89eb8010196bb88b3b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string timeout
    uint8 retries
    bool moving_call
    bool power_call
    bool terminal_call
    bool charger_call
    bool power_splitter_call
    bool hands_head_call
    bool touch_right_call
    bool touch_left_call
    bool touch_head_call
    bool moving_debug
    bool power_debug
    bool terminal_debug
    bool charger_debug
    bool power_splitter_debug
    bool hands_head_debug
    bool touch_right_debug
    bool touch_left_debug
    bool touch_head_debug
    uint32 moving_errors
    uint32 power_errors
    uint32 terminal_errors
    uint32 charger_errors
    uint32 power_splitter_errors
    uint32 hands_head_errors
    uint32 touch_right_errors
    uint32 touch_left_errors
    uint32 touch_head_errors
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Modbus(null);
    if (msg.timeout !== undefined) {
      resolved.timeout = msg.timeout;
    }
    else {
      resolved.timeout = ''
    }

    if (msg.retries !== undefined) {
      resolved.retries = msg.retries;
    }
    else {
      resolved.retries = 0
    }

    if (msg.moving_call !== undefined) {
      resolved.moving_call = msg.moving_call;
    }
    else {
      resolved.moving_call = false
    }

    if (msg.power_call !== undefined) {
      resolved.power_call = msg.power_call;
    }
    else {
      resolved.power_call = false
    }

    if (msg.terminal_call !== undefined) {
      resolved.terminal_call = msg.terminal_call;
    }
    else {
      resolved.terminal_call = false
    }

    if (msg.charger_call !== undefined) {
      resolved.charger_call = msg.charger_call;
    }
    else {
      resolved.charger_call = false
    }

    if (msg.power_splitter_call !== undefined) {
      resolved.power_splitter_call = msg.power_splitter_call;
    }
    else {
      resolved.power_splitter_call = false
    }

    if (msg.hands_head_call !== undefined) {
      resolved.hands_head_call = msg.hands_head_call;
    }
    else {
      resolved.hands_head_call = false
    }

    if (msg.touch_right_call !== undefined) {
      resolved.touch_right_call = msg.touch_right_call;
    }
    else {
      resolved.touch_right_call = false
    }

    if (msg.touch_left_call !== undefined) {
      resolved.touch_left_call = msg.touch_left_call;
    }
    else {
      resolved.touch_left_call = false
    }

    if (msg.touch_head_call !== undefined) {
      resolved.touch_head_call = msg.touch_head_call;
    }
    else {
      resolved.touch_head_call = false
    }

    if (msg.moving_debug !== undefined) {
      resolved.moving_debug = msg.moving_debug;
    }
    else {
      resolved.moving_debug = false
    }

    if (msg.power_debug !== undefined) {
      resolved.power_debug = msg.power_debug;
    }
    else {
      resolved.power_debug = false
    }

    if (msg.terminal_debug !== undefined) {
      resolved.terminal_debug = msg.terminal_debug;
    }
    else {
      resolved.terminal_debug = false
    }

    if (msg.charger_debug !== undefined) {
      resolved.charger_debug = msg.charger_debug;
    }
    else {
      resolved.charger_debug = false
    }

    if (msg.power_splitter_debug !== undefined) {
      resolved.power_splitter_debug = msg.power_splitter_debug;
    }
    else {
      resolved.power_splitter_debug = false
    }

    if (msg.hands_head_debug !== undefined) {
      resolved.hands_head_debug = msg.hands_head_debug;
    }
    else {
      resolved.hands_head_debug = false
    }

    if (msg.touch_right_debug !== undefined) {
      resolved.touch_right_debug = msg.touch_right_debug;
    }
    else {
      resolved.touch_right_debug = false
    }

    if (msg.touch_left_debug !== undefined) {
      resolved.touch_left_debug = msg.touch_left_debug;
    }
    else {
      resolved.touch_left_debug = false
    }

    if (msg.touch_head_debug !== undefined) {
      resolved.touch_head_debug = msg.touch_head_debug;
    }
    else {
      resolved.touch_head_debug = false
    }

    if (msg.moving_errors !== undefined) {
      resolved.moving_errors = msg.moving_errors;
    }
    else {
      resolved.moving_errors = 0
    }

    if (msg.power_errors !== undefined) {
      resolved.power_errors = msg.power_errors;
    }
    else {
      resolved.power_errors = 0
    }

    if (msg.terminal_errors !== undefined) {
      resolved.terminal_errors = msg.terminal_errors;
    }
    else {
      resolved.terminal_errors = 0
    }

    if (msg.charger_errors !== undefined) {
      resolved.charger_errors = msg.charger_errors;
    }
    else {
      resolved.charger_errors = 0
    }

    if (msg.power_splitter_errors !== undefined) {
      resolved.power_splitter_errors = msg.power_splitter_errors;
    }
    else {
      resolved.power_splitter_errors = 0
    }

    if (msg.hands_head_errors !== undefined) {
      resolved.hands_head_errors = msg.hands_head_errors;
    }
    else {
      resolved.hands_head_errors = 0
    }

    if (msg.touch_right_errors !== undefined) {
      resolved.touch_right_errors = msg.touch_right_errors;
    }
    else {
      resolved.touch_right_errors = 0
    }

    if (msg.touch_left_errors !== undefined) {
      resolved.touch_left_errors = msg.touch_left_errors;
    }
    else {
      resolved.touch_left_errors = 0
    }

    if (msg.touch_head_errors !== undefined) {
      resolved.touch_head_errors = msg.touch_head_errors;
    }
    else {
      resolved.touch_head_errors = 0
    }

    return resolved;
    }
};

module.exports = Modbus;

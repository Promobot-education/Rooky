// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ID = require('./ID.js');
let LinguoPattern = require('./LinguoPattern.js');
let Replica = require('./Replica.js');

//-----------------------------------------------------------

class Answer {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.source = null;
      this.pattern = null;
      this.question = null;
      this.replica = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = new ID();
      }
      if (initObj.hasOwnProperty('source')) {
        this.source = initObj.source
      }
      else {
        this.source = 0;
      }
      if (initObj.hasOwnProperty('pattern')) {
        this.pattern = initObj.pattern
      }
      else {
        this.pattern = new LinguoPattern();
      }
      if (initObj.hasOwnProperty('question')) {
        this.question = initObj.question
      }
      else {
        this.question = '';
      }
      if (initObj.hasOwnProperty('replica')) {
        this.replica = initObj.replica
      }
      else {
        this.replica = new Replica();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Answer
    // Serialize message field [id]
    bufferOffset = ID.serialize(obj.id, buffer, bufferOffset);
    // Serialize message field [source]
    bufferOffset = _serializer.uint8(obj.source, buffer, bufferOffset);
    // Serialize message field [pattern]
    bufferOffset = LinguoPattern.serialize(obj.pattern, buffer, bufferOffset);
    // Serialize message field [question]
    bufferOffset = _serializer.string(obj.question, buffer, bufferOffset);
    // Serialize message field [replica]
    bufferOffset = Replica.serialize(obj.replica, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Answer
    let len;
    let data = new Answer(null);
    // Deserialize message field [id]
    data.id = ID.deserialize(buffer, bufferOffset);
    // Deserialize message field [source]
    data.source = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [pattern]
    data.pattern = LinguoPattern.deserialize(buffer, bufferOffset);
    // Deserialize message field [question]
    data.question = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [replica]
    data.replica = Replica.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += ID.getMessageSize(object.id);
    length += LinguoPattern.getMessageSize(object.pattern);
    length += object.question.length;
    length += Replica.getMessageSize(object.replica);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Answer';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bb1b8625bc3e2cd93648f205ba94e0a3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/ID id
    uint8 source
    promobot_msgs/LinguoPattern pattern
    string question
    promobot_msgs/Replica replica
    
    ================================================================================
    MSG: promobot_msgs/ID
    uint32 id
    string uuid
    
    ================================================================================
    MSG: promobot_msgs/LinguoPattern
    promobot_msgs/ID id
    string text
    
    ================================================================================
    MSG: promobot_msgs/Replica
    promobot_msgs/ID id
    promobot_msgs/ID category
    promobot_msgs/ID anchor
    string text
    string screentext
    string url
    string action
    uint8 animation
    uint16 type
    bool interrupt_by_hark
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Answer(null);
    if (msg.id !== undefined) {
      resolved.id = ID.Resolve(msg.id)
    }
    else {
      resolved.id = new ID()
    }

    if (msg.source !== undefined) {
      resolved.source = msg.source;
    }
    else {
      resolved.source = 0
    }

    if (msg.pattern !== undefined) {
      resolved.pattern = LinguoPattern.Resolve(msg.pattern)
    }
    else {
      resolved.pattern = new LinguoPattern()
    }

    if (msg.question !== undefined) {
      resolved.question = msg.question;
    }
    else {
      resolved.question = ''
    }

    if (msg.replica !== undefined) {
      resolved.replica = Replica.Resolve(msg.replica)
    }
    else {
      resolved.replica = new Replica()
    }

    return resolved;
    }
};

module.exports = Answer;

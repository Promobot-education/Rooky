// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BodyJoints {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Elbow_Left = null;
      this.ShoulderSide_Left = null;
      this.ShoulderFront_Left = null;
      this.Elbow_Right = null;
      this.ShoulderSide_Right = null;
      this.ShoulderFront_Right = null;
      this.BodySide = null;
      this.BodyFront = null;
      this.NeckSide = null;
      this.NeckFront = null;
      this.WristRotation_Left = null;
      this.WristRotation_Right = null;
      this.ElbowRotation_Left = null;
      this.ElbowRotation_Right = null;
      this.NeckRotation = null;
      this.BodyRotation = null;
    }
    else {
      if (initObj.hasOwnProperty('Elbow_Left')) {
        this.Elbow_Left = initObj.Elbow_Left
      }
      else {
        this.Elbow_Left = 0;
      }
      if (initObj.hasOwnProperty('ShoulderSide_Left')) {
        this.ShoulderSide_Left = initObj.ShoulderSide_Left
      }
      else {
        this.ShoulderSide_Left = 0;
      }
      if (initObj.hasOwnProperty('ShoulderFront_Left')) {
        this.ShoulderFront_Left = initObj.ShoulderFront_Left
      }
      else {
        this.ShoulderFront_Left = 0;
      }
      if (initObj.hasOwnProperty('Elbow_Right')) {
        this.Elbow_Right = initObj.Elbow_Right
      }
      else {
        this.Elbow_Right = 0;
      }
      if (initObj.hasOwnProperty('ShoulderSide_Right')) {
        this.ShoulderSide_Right = initObj.ShoulderSide_Right
      }
      else {
        this.ShoulderSide_Right = 0;
      }
      if (initObj.hasOwnProperty('ShoulderFront_Right')) {
        this.ShoulderFront_Right = initObj.ShoulderFront_Right
      }
      else {
        this.ShoulderFront_Right = 0;
      }
      if (initObj.hasOwnProperty('BodySide')) {
        this.BodySide = initObj.BodySide
      }
      else {
        this.BodySide = 0;
      }
      if (initObj.hasOwnProperty('BodyFront')) {
        this.BodyFront = initObj.BodyFront
      }
      else {
        this.BodyFront = 0;
      }
      if (initObj.hasOwnProperty('NeckSide')) {
        this.NeckSide = initObj.NeckSide
      }
      else {
        this.NeckSide = 0;
      }
      if (initObj.hasOwnProperty('NeckFront')) {
        this.NeckFront = initObj.NeckFront
      }
      else {
        this.NeckFront = 0;
      }
      if (initObj.hasOwnProperty('WristRotation_Left')) {
        this.WristRotation_Left = initObj.WristRotation_Left
      }
      else {
        this.WristRotation_Left = 0;
      }
      if (initObj.hasOwnProperty('WristRotation_Right')) {
        this.WristRotation_Right = initObj.WristRotation_Right
      }
      else {
        this.WristRotation_Right = 0;
      }
      if (initObj.hasOwnProperty('ElbowRotation_Left')) {
        this.ElbowRotation_Left = initObj.ElbowRotation_Left
      }
      else {
        this.ElbowRotation_Left = 0;
      }
      if (initObj.hasOwnProperty('ElbowRotation_Right')) {
        this.ElbowRotation_Right = initObj.ElbowRotation_Right
      }
      else {
        this.ElbowRotation_Right = 0;
      }
      if (initObj.hasOwnProperty('NeckRotation')) {
        this.NeckRotation = initObj.NeckRotation
      }
      else {
        this.NeckRotation = 0;
      }
      if (initObj.hasOwnProperty('BodyRotation')) {
        this.BodyRotation = initObj.BodyRotation
      }
      else {
        this.BodyRotation = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BodyJoints
    // Serialize message field [Elbow_Left]
    bufferOffset = _serializer.int16(obj.Elbow_Left, buffer, bufferOffset);
    // Serialize message field [ShoulderSide_Left]
    bufferOffset = _serializer.int16(obj.ShoulderSide_Left, buffer, bufferOffset);
    // Serialize message field [ShoulderFront_Left]
    bufferOffset = _serializer.int16(obj.ShoulderFront_Left, buffer, bufferOffset);
    // Serialize message field [Elbow_Right]
    bufferOffset = _serializer.int16(obj.Elbow_Right, buffer, bufferOffset);
    // Serialize message field [ShoulderSide_Right]
    bufferOffset = _serializer.int16(obj.ShoulderSide_Right, buffer, bufferOffset);
    // Serialize message field [ShoulderFront_Right]
    bufferOffset = _serializer.int16(obj.ShoulderFront_Right, buffer, bufferOffset);
    // Serialize message field [BodySide]
    bufferOffset = _serializer.int16(obj.BodySide, buffer, bufferOffset);
    // Serialize message field [BodyFront]
    bufferOffset = _serializer.int16(obj.BodyFront, buffer, bufferOffset);
    // Serialize message field [NeckSide]
    bufferOffset = _serializer.int16(obj.NeckSide, buffer, bufferOffset);
    // Serialize message field [NeckFront]
    bufferOffset = _serializer.int16(obj.NeckFront, buffer, bufferOffset);
    // Serialize message field [WristRotation_Left]
    bufferOffset = _serializer.int16(obj.WristRotation_Left, buffer, bufferOffset);
    // Serialize message field [WristRotation_Right]
    bufferOffset = _serializer.int16(obj.WristRotation_Right, buffer, bufferOffset);
    // Serialize message field [ElbowRotation_Left]
    bufferOffset = _serializer.int16(obj.ElbowRotation_Left, buffer, bufferOffset);
    // Serialize message field [ElbowRotation_Right]
    bufferOffset = _serializer.int16(obj.ElbowRotation_Right, buffer, bufferOffset);
    // Serialize message field [NeckRotation]
    bufferOffset = _serializer.int16(obj.NeckRotation, buffer, bufferOffset);
    // Serialize message field [BodyRotation]
    bufferOffset = _serializer.int16(obj.BodyRotation, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BodyJoints
    let len;
    let data = new BodyJoints(null);
    // Deserialize message field [Elbow_Left]
    data.Elbow_Left = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ShoulderSide_Left]
    data.ShoulderSide_Left = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ShoulderFront_Left]
    data.ShoulderFront_Left = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [Elbow_Right]
    data.Elbow_Right = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ShoulderSide_Right]
    data.ShoulderSide_Right = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ShoulderFront_Right]
    data.ShoulderFront_Right = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [BodySide]
    data.BodySide = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [BodyFront]
    data.BodyFront = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [NeckSide]
    data.NeckSide = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [NeckFront]
    data.NeckFront = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [WristRotation_Left]
    data.WristRotation_Left = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [WristRotation_Right]
    data.WristRotation_Right = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ElbowRotation_Left]
    data.ElbowRotation_Left = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [ElbowRotation_Right]
    data.ElbowRotation_Right = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [NeckRotation]
    data.NeckRotation = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [BodyRotation]
    data.BodyRotation = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/BodyJoints';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '94a67c1a0a59f355fec2080f0087f61b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 Elbow_Left
    int16 ShoulderSide_Left
    int16 ShoulderFront_Left
    int16 Elbow_Right 
    int16 ShoulderSide_Right 
    int16 ShoulderFront_Right
    int16 BodySide
    int16 BodyFront
    int16 NeckSide
    int16 NeckFront
    int16 WristRotation_Left
    int16 WristRotation_Right
    int16 ElbowRotation_Left
    int16 ElbowRotation_Right
    int16 NeckRotation
    int16 BodyRotation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BodyJoints(null);
    if (msg.Elbow_Left !== undefined) {
      resolved.Elbow_Left = msg.Elbow_Left;
    }
    else {
      resolved.Elbow_Left = 0
    }

    if (msg.ShoulderSide_Left !== undefined) {
      resolved.ShoulderSide_Left = msg.ShoulderSide_Left;
    }
    else {
      resolved.ShoulderSide_Left = 0
    }

    if (msg.ShoulderFront_Left !== undefined) {
      resolved.ShoulderFront_Left = msg.ShoulderFront_Left;
    }
    else {
      resolved.ShoulderFront_Left = 0
    }

    if (msg.Elbow_Right !== undefined) {
      resolved.Elbow_Right = msg.Elbow_Right;
    }
    else {
      resolved.Elbow_Right = 0
    }

    if (msg.ShoulderSide_Right !== undefined) {
      resolved.ShoulderSide_Right = msg.ShoulderSide_Right;
    }
    else {
      resolved.ShoulderSide_Right = 0
    }

    if (msg.ShoulderFront_Right !== undefined) {
      resolved.ShoulderFront_Right = msg.ShoulderFront_Right;
    }
    else {
      resolved.ShoulderFront_Right = 0
    }

    if (msg.BodySide !== undefined) {
      resolved.BodySide = msg.BodySide;
    }
    else {
      resolved.BodySide = 0
    }

    if (msg.BodyFront !== undefined) {
      resolved.BodyFront = msg.BodyFront;
    }
    else {
      resolved.BodyFront = 0
    }

    if (msg.NeckSide !== undefined) {
      resolved.NeckSide = msg.NeckSide;
    }
    else {
      resolved.NeckSide = 0
    }

    if (msg.NeckFront !== undefined) {
      resolved.NeckFront = msg.NeckFront;
    }
    else {
      resolved.NeckFront = 0
    }

    if (msg.WristRotation_Left !== undefined) {
      resolved.WristRotation_Left = msg.WristRotation_Left;
    }
    else {
      resolved.WristRotation_Left = 0
    }

    if (msg.WristRotation_Right !== undefined) {
      resolved.WristRotation_Right = msg.WristRotation_Right;
    }
    else {
      resolved.WristRotation_Right = 0
    }

    if (msg.ElbowRotation_Left !== undefined) {
      resolved.ElbowRotation_Left = msg.ElbowRotation_Left;
    }
    else {
      resolved.ElbowRotation_Left = 0
    }

    if (msg.ElbowRotation_Right !== undefined) {
      resolved.ElbowRotation_Right = msg.ElbowRotation_Right;
    }
    else {
      resolved.ElbowRotation_Right = 0
    }

    if (msg.NeckRotation !== undefined) {
      resolved.NeckRotation = msg.NeckRotation;
    }
    else {
      resolved.NeckRotation = 0
    }

    if (msg.BodyRotation !== undefined) {
      resolved.BodyRotation = msg.BodyRotation;
    }
    else {
      resolved.BodyRotation = 0
    }

    return resolved;
    }
};

module.exports = BodyJoints;

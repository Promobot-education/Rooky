// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Gender = require('./Gender.js');

//-----------------------------------------------------------

class FaceBiometry {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.gender = null;
      this.age = null;
      this.emotion = null;
    }
    else {
      if (initObj.hasOwnProperty('gender')) {
        this.gender = initObj.gender
      }
      else {
        this.gender = new Gender();
      }
      if (initObj.hasOwnProperty('age')) {
        this.age = initObj.age
      }
      else {
        this.age = 0.0;
      }
      if (initObj.hasOwnProperty('emotion')) {
        this.emotion = initObj.emotion
      }
      else {
        this.emotion = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FaceBiometry
    // Serialize message field [gender]
    bufferOffset = Gender.serialize(obj.gender, buffer, bufferOffset);
    // Serialize message field [age]
    bufferOffset = _serializer.float32(obj.age, buffer, bufferOffset);
    // Serialize message field [emotion]
    bufferOffset = _serializer.string(obj.emotion, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FaceBiometry
    let len;
    let data = new FaceBiometry(null);
    // Deserialize message field [gender]
    data.gender = Gender.deserialize(buffer, bufferOffset);
    // Deserialize message field [age]
    data.age = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [emotion]
    data.emotion = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.emotion.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/FaceBiometry';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0a0cee59a097ce85ceb0527238c4e0c3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/Gender gender
    float32 age
    string emotion
    
    ================================================================================
    MSG: promobot_msgs/Gender
    uint8 gender
    uint8 UNKNOWN   = 0
    uint8 MALE      = 1
    uint8 FEMALE    = 2
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FaceBiometry(null);
    if (msg.gender !== undefined) {
      resolved.gender = Gender.Resolve(msg.gender)
    }
    else {
      resolved.gender = new Gender()
    }

    if (msg.age !== undefined) {
      resolved.age = msg.age;
    }
    else {
      resolved.age = 0.0
    }

    if (msg.emotion !== undefined) {
      resolved.emotion = msg.emotion;
    }
    else {
      resolved.emotion = ''
    }

    return resolved;
    }
};

module.exports = FaceBiometry;

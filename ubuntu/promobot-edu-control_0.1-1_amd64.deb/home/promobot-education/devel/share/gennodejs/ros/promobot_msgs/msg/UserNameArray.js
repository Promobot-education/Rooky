// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let UserName = require('./UserName.js');

//-----------------------------------------------------------

class UserNameArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.usernames = null;
    }
    else {
      if (initObj.hasOwnProperty('usernames')) {
        this.usernames = initObj.usernames
      }
      else {
        this.usernames = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UserNameArray
    // Serialize message field [usernames]
    // Serialize the length for message field [usernames]
    bufferOffset = _serializer.uint32(obj.usernames.length, buffer, bufferOffset);
    obj.usernames.forEach((val) => {
      bufferOffset = UserName.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UserNameArray
    let len;
    let data = new UserNameArray(null);
    // Deserialize message field [usernames]
    // Deserialize array length for message field [usernames]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.usernames = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.usernames[i] = UserName.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.usernames.forEach((val) => {
      length += UserName.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/UserNameArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8a95932b1528461aaca9d33c7f4bf788';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/UserName[] usernames
    
    ================================================================================
    MSG: promobot_msgs/UserName
    int64 id
    int64 track_id
    uint16 action
    string username
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UserNameArray(null);
    if (msg.usernames !== undefined) {
      resolved.usernames = new Array(msg.usernames.length);
      for (let i = 0; i < resolved.usernames.length; ++i) {
        resolved.usernames[i] = UserName.Resolve(msg.usernames[i]);
      }
    }
    else {
      resolved.usernames = []
    }

    return resolved;
    }
};

module.exports = UserNameArray;

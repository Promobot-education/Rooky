// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RealSenseRanges {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.s_all = null;
      this.s_l = null;
      this.s_m = null;
      this.s_r = null;
      this.s_1 = null;
      this.s_2 = null;
      this.s_3 = null;
      this.s_4 = null;
      this.s_1_1 = null;
      this.s_1_2 = null;
      this.s_1_3 = null;
      this.s_2_1 = null;
      this.s_2_2 = null;
      this.s_2_3 = null;
      this.s_3_1 = null;
      this.s_3_2 = null;
      this.s_3_3 = null;
      this.s_4_1 = null;
      this.s_4_2 = null;
      this.s_4_3 = null;
    }
    else {
      if (initObj.hasOwnProperty('s_all')) {
        this.s_all = initObj.s_all
      }
      else {
        this.s_all = 0;
      }
      if (initObj.hasOwnProperty('s_l')) {
        this.s_l = initObj.s_l
      }
      else {
        this.s_l = 0;
      }
      if (initObj.hasOwnProperty('s_m')) {
        this.s_m = initObj.s_m
      }
      else {
        this.s_m = 0;
      }
      if (initObj.hasOwnProperty('s_r')) {
        this.s_r = initObj.s_r
      }
      else {
        this.s_r = 0;
      }
      if (initObj.hasOwnProperty('s_1')) {
        this.s_1 = initObj.s_1
      }
      else {
        this.s_1 = 0;
      }
      if (initObj.hasOwnProperty('s_2')) {
        this.s_2 = initObj.s_2
      }
      else {
        this.s_2 = 0;
      }
      if (initObj.hasOwnProperty('s_3')) {
        this.s_3 = initObj.s_3
      }
      else {
        this.s_3 = 0;
      }
      if (initObj.hasOwnProperty('s_4')) {
        this.s_4 = initObj.s_4
      }
      else {
        this.s_4 = 0;
      }
      if (initObj.hasOwnProperty('s_1_1')) {
        this.s_1_1 = initObj.s_1_1
      }
      else {
        this.s_1_1 = 0;
      }
      if (initObj.hasOwnProperty('s_1_2')) {
        this.s_1_2 = initObj.s_1_2
      }
      else {
        this.s_1_2 = 0;
      }
      if (initObj.hasOwnProperty('s_1_3')) {
        this.s_1_3 = initObj.s_1_3
      }
      else {
        this.s_1_3 = 0;
      }
      if (initObj.hasOwnProperty('s_2_1')) {
        this.s_2_1 = initObj.s_2_1
      }
      else {
        this.s_2_1 = 0;
      }
      if (initObj.hasOwnProperty('s_2_2')) {
        this.s_2_2 = initObj.s_2_2
      }
      else {
        this.s_2_2 = 0;
      }
      if (initObj.hasOwnProperty('s_2_3')) {
        this.s_2_3 = initObj.s_2_3
      }
      else {
        this.s_2_3 = 0;
      }
      if (initObj.hasOwnProperty('s_3_1')) {
        this.s_3_1 = initObj.s_3_1
      }
      else {
        this.s_3_1 = 0;
      }
      if (initObj.hasOwnProperty('s_3_2')) {
        this.s_3_2 = initObj.s_3_2
      }
      else {
        this.s_3_2 = 0;
      }
      if (initObj.hasOwnProperty('s_3_3')) {
        this.s_3_3 = initObj.s_3_3
      }
      else {
        this.s_3_3 = 0;
      }
      if (initObj.hasOwnProperty('s_4_1')) {
        this.s_4_1 = initObj.s_4_1
      }
      else {
        this.s_4_1 = 0;
      }
      if (initObj.hasOwnProperty('s_4_2')) {
        this.s_4_2 = initObj.s_4_2
      }
      else {
        this.s_4_2 = 0;
      }
      if (initObj.hasOwnProperty('s_4_3')) {
        this.s_4_3 = initObj.s_4_3
      }
      else {
        this.s_4_3 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RealSenseRanges
    // Serialize message field [s_all]
    bufferOffset = _serializer.uint8(obj.s_all, buffer, bufferOffset);
    // Serialize message field [s_l]
    bufferOffset = _serializer.uint8(obj.s_l, buffer, bufferOffset);
    // Serialize message field [s_m]
    bufferOffset = _serializer.uint8(obj.s_m, buffer, bufferOffset);
    // Serialize message field [s_r]
    bufferOffset = _serializer.uint8(obj.s_r, buffer, bufferOffset);
    // Serialize message field [s_1]
    bufferOffset = _serializer.uint8(obj.s_1, buffer, bufferOffset);
    // Serialize message field [s_2]
    bufferOffset = _serializer.uint8(obj.s_2, buffer, bufferOffset);
    // Serialize message field [s_3]
    bufferOffset = _serializer.uint8(obj.s_3, buffer, bufferOffset);
    // Serialize message field [s_4]
    bufferOffset = _serializer.uint8(obj.s_4, buffer, bufferOffset);
    // Serialize message field [s_1_1]
    bufferOffset = _serializer.uint8(obj.s_1_1, buffer, bufferOffset);
    // Serialize message field [s_1_2]
    bufferOffset = _serializer.uint8(obj.s_1_2, buffer, bufferOffset);
    // Serialize message field [s_1_3]
    bufferOffset = _serializer.uint8(obj.s_1_3, buffer, bufferOffset);
    // Serialize message field [s_2_1]
    bufferOffset = _serializer.uint8(obj.s_2_1, buffer, bufferOffset);
    // Serialize message field [s_2_2]
    bufferOffset = _serializer.uint8(obj.s_2_2, buffer, bufferOffset);
    // Serialize message field [s_2_3]
    bufferOffset = _serializer.uint8(obj.s_2_3, buffer, bufferOffset);
    // Serialize message field [s_3_1]
    bufferOffset = _serializer.uint8(obj.s_3_1, buffer, bufferOffset);
    // Serialize message field [s_3_2]
    bufferOffset = _serializer.uint8(obj.s_3_2, buffer, bufferOffset);
    // Serialize message field [s_3_3]
    bufferOffset = _serializer.uint8(obj.s_3_3, buffer, bufferOffset);
    // Serialize message field [s_4_1]
    bufferOffset = _serializer.uint8(obj.s_4_1, buffer, bufferOffset);
    // Serialize message field [s_4_2]
    bufferOffset = _serializer.uint8(obj.s_4_2, buffer, bufferOffset);
    // Serialize message field [s_4_3]
    bufferOffset = _serializer.uint8(obj.s_4_3, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RealSenseRanges
    let len;
    let data = new RealSenseRanges(null);
    // Deserialize message field [s_all]
    data.s_all = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_l]
    data.s_l = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_m]
    data.s_m = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_r]
    data.s_r = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_1]
    data.s_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_2]
    data.s_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_3]
    data.s_3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_4]
    data.s_4 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_1_1]
    data.s_1_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_1_2]
    data.s_1_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_1_3]
    data.s_1_3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_2_1]
    data.s_2_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_2_2]
    data.s_2_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_2_3]
    data.s_2_3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_3_1]
    data.s_3_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_3_2]
    data.s_3_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_3_3]
    data.s_3_3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_4_1]
    data.s_4_1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_4_2]
    data.s_4_2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [s_4_3]
    data.s_4_3 = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/RealSenseRanges';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e6134dc4db0a9faa62c4d6863a3b9af2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 s_all #минимальное расстояние по всему кадру
    uint8 s_l #минимальное расстояние по 1 колонке (левая)
    uint8 s_m #минимальное расстояние по 2 колонке (средняя)
    uint8 s_r #минимальное расстояние по 3 колонке (правая)
    uint8 s_1 #минимальное расстояние по 1 строке (верхняя) 
    uint8 s_2 #минимальное расстояние по 2 строке
    uint8 s_3 #минимальное расстояние по 3 строке
    uint8 s_4 #минимальное расстояние по 4 строке (нижняя)
    uint8 s_1_1 #минимальное расстояние в секторе 1 1
    uint8 s_1_2 #минимальное расстояние в секторе 1 2
    uint8 s_1_3 #минимальное расстояние в секторе 1 3
    uint8 s_2_1 #минимальное расстояние в секторе 2 1
    uint8 s_2_2 #минимальное расстояние в секторе 2 2
    uint8 s_2_3 #минимальное расстояние в секторе 2 3
    uint8 s_3_1 #минимальное расстояние в секторе 3 1
    uint8 s_3_2 #минимальное расстояние в секторе 3 2
    uint8 s_3_3 #минимальное расстояние в секторе 3 3
    uint8 s_4_1 #минимальное расстояние в секторе 4 1
    uint8 s_4_2 #минимальное расстояние в секторе 4 2
    uint8 s_4_3 #минимальное расстояние в секторе 4 3
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RealSenseRanges(null);
    if (msg.s_all !== undefined) {
      resolved.s_all = msg.s_all;
    }
    else {
      resolved.s_all = 0
    }

    if (msg.s_l !== undefined) {
      resolved.s_l = msg.s_l;
    }
    else {
      resolved.s_l = 0
    }

    if (msg.s_m !== undefined) {
      resolved.s_m = msg.s_m;
    }
    else {
      resolved.s_m = 0
    }

    if (msg.s_r !== undefined) {
      resolved.s_r = msg.s_r;
    }
    else {
      resolved.s_r = 0
    }

    if (msg.s_1 !== undefined) {
      resolved.s_1 = msg.s_1;
    }
    else {
      resolved.s_1 = 0
    }

    if (msg.s_2 !== undefined) {
      resolved.s_2 = msg.s_2;
    }
    else {
      resolved.s_2 = 0
    }

    if (msg.s_3 !== undefined) {
      resolved.s_3 = msg.s_3;
    }
    else {
      resolved.s_3 = 0
    }

    if (msg.s_4 !== undefined) {
      resolved.s_4 = msg.s_4;
    }
    else {
      resolved.s_4 = 0
    }

    if (msg.s_1_1 !== undefined) {
      resolved.s_1_1 = msg.s_1_1;
    }
    else {
      resolved.s_1_1 = 0
    }

    if (msg.s_1_2 !== undefined) {
      resolved.s_1_2 = msg.s_1_2;
    }
    else {
      resolved.s_1_2 = 0
    }

    if (msg.s_1_3 !== undefined) {
      resolved.s_1_3 = msg.s_1_3;
    }
    else {
      resolved.s_1_3 = 0
    }

    if (msg.s_2_1 !== undefined) {
      resolved.s_2_1 = msg.s_2_1;
    }
    else {
      resolved.s_2_1 = 0
    }

    if (msg.s_2_2 !== undefined) {
      resolved.s_2_2 = msg.s_2_2;
    }
    else {
      resolved.s_2_2 = 0
    }

    if (msg.s_2_3 !== undefined) {
      resolved.s_2_3 = msg.s_2_3;
    }
    else {
      resolved.s_2_3 = 0
    }

    if (msg.s_3_1 !== undefined) {
      resolved.s_3_1 = msg.s_3_1;
    }
    else {
      resolved.s_3_1 = 0
    }

    if (msg.s_3_2 !== undefined) {
      resolved.s_3_2 = msg.s_3_2;
    }
    else {
      resolved.s_3_2 = 0
    }

    if (msg.s_3_3 !== undefined) {
      resolved.s_3_3 = msg.s_3_3;
    }
    else {
      resolved.s_3_3 = 0
    }

    if (msg.s_4_1 !== undefined) {
      resolved.s_4_1 = msg.s_4_1;
    }
    else {
      resolved.s_4_1 = 0
    }

    if (msg.s_4_2 !== undefined) {
      resolved.s_4_2 = msg.s_4_2;
    }
    else {
      resolved.s_4_2 = 0
    }

    if (msg.s_4_3 !== undefined) {
      resolved.s_4_3 = msg.s_4_3;
    }
    else {
      resolved.s_4_3 = 0
    }

    return resolved;
    }
};

module.exports = RealSenseRanges;

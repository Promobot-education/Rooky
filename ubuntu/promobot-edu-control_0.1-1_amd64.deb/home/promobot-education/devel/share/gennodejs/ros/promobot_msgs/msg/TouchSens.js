// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TouchSens {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.left_hand = null;
      this.right_hand = null;
      this.head_left = null;
      this.head_right = null;
      this.head_center = null;
    }
    else {
      if (initObj.hasOwnProperty('left_hand')) {
        this.left_hand = initObj.left_hand
      }
      else {
        this.left_hand = false;
      }
      if (initObj.hasOwnProperty('right_hand')) {
        this.right_hand = initObj.right_hand
      }
      else {
        this.right_hand = false;
      }
      if (initObj.hasOwnProperty('head_left')) {
        this.head_left = initObj.head_left
      }
      else {
        this.head_left = false;
      }
      if (initObj.hasOwnProperty('head_right')) {
        this.head_right = initObj.head_right
      }
      else {
        this.head_right = false;
      }
      if (initObj.hasOwnProperty('head_center')) {
        this.head_center = initObj.head_center
      }
      else {
        this.head_center = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TouchSens
    // Serialize message field [left_hand]
    bufferOffset = _serializer.bool(obj.left_hand, buffer, bufferOffset);
    // Serialize message field [right_hand]
    bufferOffset = _serializer.bool(obj.right_hand, buffer, bufferOffset);
    // Serialize message field [head_left]
    bufferOffset = _serializer.bool(obj.head_left, buffer, bufferOffset);
    // Serialize message field [head_right]
    bufferOffset = _serializer.bool(obj.head_right, buffer, bufferOffset);
    // Serialize message field [head_center]
    bufferOffset = _serializer.bool(obj.head_center, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TouchSens
    let len;
    let data = new TouchSens(null);
    // Deserialize message field [left_hand]
    data.left_hand = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [right_hand]
    data.right_hand = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [head_left]
    data.head_left = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [head_right]
    data.head_right = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [head_center]
    data.head_center = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/TouchSens';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '45f52041cf2bedcfc44403aad16f5dd0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool left_hand
    bool right_hand
    bool head_left
    bool head_right
    bool head_center
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TouchSens(null);
    if (msg.left_hand !== undefined) {
      resolved.left_hand = msg.left_hand;
    }
    else {
      resolved.left_hand = false
    }

    if (msg.right_hand !== undefined) {
      resolved.right_hand = msg.right_hand;
    }
    else {
      resolved.right_hand = false
    }

    if (msg.head_left !== undefined) {
      resolved.head_left = msg.head_left;
    }
    else {
      resolved.head_left = false
    }

    if (msg.head_right !== undefined) {
      resolved.head_right = msg.head_right;
    }
    else {
      resolved.head_right = false
    }

    if (msg.head_center !== undefined) {
      resolved.head_center = msg.head_center;
    }
    else {
      resolved.head_center = false
    }

    return resolved;
    }
};

module.exports = TouchSens;

// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let promobot_msgs = _finder('promobot_msgs');

//-----------------------------------------------------------

class GetLinguoLevelsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.only_installed = null;
    }
    else {
      if (initObj.hasOwnProperty('only_installed')) {
        this.only_installed = initObj.only_installed
      }
      else {
        this.only_installed = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetLinguoLevelsRequest
    // Serialize message field [only_installed]
    bufferOffset = _serializer.bool(obj.only_installed, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetLinguoLevelsRequest
    let len;
    let data = new GetLinguoLevelsRequest(null);
    // Deserialize message field [only_installed]
    data.only_installed = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/GetLinguoLevelsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5e63cb5c66b03fb137204f38ca1932fd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool only_installed
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetLinguoLevelsRequest(null);
    if (msg.only_installed !== undefined) {
      resolved.only_installed = msg.only_installed;
    }
    else {
      resolved.only_installed = false
    }

    return resolved;
    }
};

class GetLinguoLevelsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.levels = null;
    }
    else {
      if (initObj.hasOwnProperty('levels')) {
        this.levels = initObj.levels
      }
      else {
        this.levels = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetLinguoLevelsResponse
    // Serialize message field [levels]
    // Serialize the length for message field [levels]
    bufferOffset = _serializer.uint32(obj.levels.length, buffer, bufferOffset);
    obj.levels.forEach((val) => {
      bufferOffset = promobot_msgs.msg.LinguoLevel.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetLinguoLevelsResponse
    let len;
    let data = new GetLinguoLevelsResponse(null);
    // Deserialize message field [levels]
    // Deserialize array length for message field [levels]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.levels = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.levels[i] = promobot_msgs.msg.LinguoLevel.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.levels.forEach((val) => {
      length += promobot_msgs.msg.LinguoLevel.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/GetLinguoLevelsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0d8c25221aa9938ff9dcf65dfdfa9024';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    promobot_msgs/LinguoLevel[] levels
    
    
    ================================================================================
    MSG: promobot_msgs/LinguoLevel
    uint16 id
    string name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetLinguoLevelsResponse(null);
    if (msg.levels !== undefined) {
      resolved.levels = new Array(msg.levels.length);
      for (let i = 0; i < resolved.levels.length; ++i) {
        resolved.levels[i] = promobot_msgs.msg.LinguoLevel.Resolve(msg.levels[i]);
      }
    }
    else {
      resolved.levels = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetLinguoLevelsRequest,
  Response: GetLinguoLevelsResponse,
  md5sum() { return '979e9b36dcb80321f0478f39210ff342'; },
  datatype() { return 'promobot_srvs/GetLinguoLevels'; }
};

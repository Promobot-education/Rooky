// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FaceSpeech {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.track_id = null;
      this.speech = null;
      this.speech_source_id = null;
      this.power = null;
    }
    else {
      if (initObj.hasOwnProperty('track_id')) {
        this.track_id = initObj.track_id
      }
      else {
        this.track_id = 0;
      }
      if (initObj.hasOwnProperty('speech')) {
        this.speech = initObj.speech
      }
      else {
        this.speech = false;
      }
      if (initObj.hasOwnProperty('speech_source_id')) {
        this.speech_source_id = initObj.speech_source_id
      }
      else {
        this.speech_source_id = 0;
      }
      if (initObj.hasOwnProperty('power')) {
        this.power = initObj.power
      }
      else {
        this.power = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FaceSpeech
    // Serialize message field [track_id]
    bufferOffset = _serializer.int64(obj.track_id, buffer, bufferOffset);
    // Serialize message field [speech]
    bufferOffset = _serializer.bool(obj.speech, buffer, bufferOffset);
    // Serialize message field [speech_source_id]
    bufferOffset = _serializer.int64(obj.speech_source_id, buffer, bufferOffset);
    // Serialize message field [power]
    bufferOffset = _serializer.float32(obj.power, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FaceSpeech
    let len;
    let data = new FaceSpeech(null);
    // Deserialize message field [track_id]
    data.track_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [speech]
    data.speech = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [speech_source_id]
    data.speech_source_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [power]
    data.power = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/FaceSpeech';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bfc07c04e22adab591ddcbf1d8f0fabc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 track_id
    bool speech
    int64 speech_source_id
    float32 power
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FaceSpeech(null);
    if (msg.track_id !== undefined) {
      resolved.track_id = msg.track_id;
    }
    else {
      resolved.track_id = 0
    }

    if (msg.speech !== undefined) {
      resolved.speech = msg.speech;
    }
    else {
      resolved.speech = false
    }

    if (msg.speech_source_id !== undefined) {
      resolved.speech_source_id = msg.speech_source_id;
    }
    else {
      resolved.speech_source_id = 0
    }

    if (msg.power !== undefined) {
      resolved.power = msg.power;
    }
    else {
      resolved.power = 0.0
    }

    return resolved;
    }
};

module.exports = FaceSpeech;

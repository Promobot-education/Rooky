
"use strict";

let FaceTrainFromTemp = require('./FaceTrainFromTemp.js');
let PowerValue = require('./PowerValue.js');
let Angles = require('./Angles.js');
let Answer = require('./Answer.js');
let ASRResult = require('./ASRResult.js');
let BodyJoints = require('./BodyJoints.js');
let DataCollect = require('./DataCollect.js');
let Dynamixel = require('./Dynamixel.js');
let DynamixelList = require('./DynamixelList.js');
let Error = require('./Error.js');
let Face = require('./Face.js');
let FaceAddStatus = require('./FaceAddStatus.js');
let FaceArray = require('./FaceArray.js');
let FaceBiometry = require('./FaceBiometry.js');
let FacePosition = require('./FacePosition.js');
let FacePositionArray = require('./FacePositionArray.js');
let FaceRect = require('./FaceRect.js');
let FaceRectArray = require('./FaceRectArray.js');
let FaceScore = require('./FaceScore.js');
let FaceSpeech = require('./FaceSpeech.js');
let FaceType = require('./FaceType.js');
let Gender = require('./Gender.js');
let HallSensors = require('./HallSensors.js');
let Hand = require('./Hand.js');
let Head = require('./Head.js');
let Head3s = require('./Head3s.js');
let ID = require('./ID.js');
let Interaction = require('./Interaction.js');
let IR = require('./IR.js');
let Light = require('./Light.js');
let LinguoLevel = require('./LinguoLevel.js');
let LinguoPattern = require('./LinguoPattern.js');
let Modbus = require('./Modbus.js');
let People = require('./People.js');
let PeopleArray = require('./PeopleArray.js');
let PeopleStamped = require('./PeopleStamped.js');
let Power = require('./Power.js');
let PowerBoardState = require('./PowerBoardState.js');
let PowerValueArray = require('./PowerValueArray.js');
let Presentation = require('./Presentation.js');
let Push = require('./Push.js');
let Question = require('./Question.js');
let Ranges = require('./Ranges.js');
let Ranges3 = require('./Ranges3.js');
let Ranges3s = require('./Ranges3s.js');
let RealSenseRanges = require('./RealSenseRanges.js');
let Replica = require('./Replica.js');
let ReplicaArray = require('./ReplicaArray.js');
let ScriptProcess = require('./ScriptProcess.js');
let Servo = require('./Servo.js');
let ServoState = require('./ServoState.js');
let ServoStates = require('./ServoStates.js');
let SipCallWithText = require('./SipCallWithText.js');
let SipCallWithWav = require('./SipCallWithWav.js');
let SipStatus = require('./SipStatus.js');
let Terminal = require('./Terminal.js');
let TouchSens = require('./TouchSens.js');
let TTSCommand = require('./TTSCommand.js');
let TTSStatus = require('./TTSStatus.js');
let UserName = require('./UserName.js');
let UserNameArray = require('./UserNameArray.js');

module.exports = {
  FaceTrainFromTemp: FaceTrainFromTemp,
  PowerValue: PowerValue,
  Angles: Angles,
  Answer: Answer,
  ASRResult: ASRResult,
  BodyJoints: BodyJoints,
  DataCollect: DataCollect,
  Dynamixel: Dynamixel,
  DynamixelList: DynamixelList,
  Error: Error,
  Face: Face,
  FaceAddStatus: FaceAddStatus,
  FaceArray: FaceArray,
  FaceBiometry: FaceBiometry,
  FacePosition: FacePosition,
  FacePositionArray: FacePositionArray,
  FaceRect: FaceRect,
  FaceRectArray: FaceRectArray,
  FaceScore: FaceScore,
  FaceSpeech: FaceSpeech,
  FaceType: FaceType,
  Gender: Gender,
  HallSensors: HallSensors,
  Hand: Hand,
  Head: Head,
  Head3s: Head3s,
  ID: ID,
  Interaction: Interaction,
  IR: IR,
  Light: Light,
  LinguoLevel: LinguoLevel,
  LinguoPattern: LinguoPattern,
  Modbus: Modbus,
  People: People,
  PeopleArray: PeopleArray,
  PeopleStamped: PeopleStamped,
  Power: Power,
  PowerBoardState: PowerBoardState,
  PowerValueArray: PowerValueArray,
  Presentation: Presentation,
  Push: Push,
  Question: Question,
  Ranges: Ranges,
  Ranges3: Ranges3,
  Ranges3s: Ranges3s,
  RealSenseRanges: RealSenseRanges,
  Replica: Replica,
  ReplicaArray: ReplicaArray,
  ScriptProcess: ScriptProcess,
  Servo: Servo,
  ServoState: ServoState,
  ServoStates: ServoStates,
  SipCallWithText: SipCallWithText,
  SipCallWithWav: SipCallWithWav,
  SipStatus: SipStatus,
  Terminal: Terminal,
  TouchSens: TouchSens,
  TTSCommand: TTSCommand,
  TTSStatus: TTSStatus,
  UserName: UserName,
  UserNameArray: UserNameArray,
};

// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Gender {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.gender = null;
    }
    else {
      if (initObj.hasOwnProperty('gender')) {
        this.gender = initObj.gender
      }
      else {
        this.gender = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Gender
    // Serialize message field [gender]
    bufferOffset = _serializer.uint8(obj.gender, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Gender
    let len;
    let data = new Gender(null);
    // Deserialize message field [gender]
    data.gender = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Gender';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3c2e03151a76c8c4faa2306d0dcc0ff6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 gender
    uint8 UNKNOWN   = 0
    uint8 MALE      = 1
    uint8 FEMALE    = 2
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Gender(null);
    if (msg.gender !== undefined) {
      resolved.gender = msg.gender;
    }
    else {
      resolved.gender = 0
    }

    return resolved;
    }
};

// Constants for message
Gender.Constants = {
  UNKNOWN: 0,
  MALE: 1,
  FEMALE: 2,
}

module.exports = Gender;

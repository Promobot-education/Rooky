
"use strict";

let Animation = require('./Animation.js')
let Bool = require('./Bool.js')
let CameraInfo = require('./CameraInfo.js')
let CompareTemplate = require('./CompareTemplate.js')
let GetAppReplica = require('./GetAppReplica.js')
let GetAppReplicaArray = require('./GetAppReplicaArray.js')
let GetHandbook = require('./GetHandbook.js')
let GetLinguoLevels = require('./GetLinguoLevels.js')
let GetReplica = require('./GetReplica.js')
let GetReplicaArray = require('./GetReplicaArray.js')
let Int8 = require('./Int8.js')
let InternetRequest = require('./InternetRequest.js')
let JoystickRumble = require('./JoystickRumble.js')
let MovementAlgorithm = require('./MovementAlgorithm.js')
let Script = require('./Script.js')
let SetLinguoLevels = require('./SetLinguoLevels.js')
let setServoCommand = require('./setServoCommand.js')
let setServoTorque = require('./setServoTorque.js')
let String = require('./String.js')
let TTSCommand = require('./TTSCommand.js')
let TTSWav = require('./TTSWav.js')

module.exports = {
  Animation: Animation,
  Bool: Bool,
  CameraInfo: CameraInfo,
  CompareTemplate: CompareTemplate,
  GetAppReplica: GetAppReplica,
  GetAppReplicaArray: GetAppReplicaArray,
  GetHandbook: GetHandbook,
  GetLinguoLevels: GetLinguoLevels,
  GetReplica: GetReplica,
  GetReplicaArray: GetReplicaArray,
  Int8: Int8,
  InternetRequest: InternetRequest,
  JoystickRumble: JoystickRumble,
  MovementAlgorithm: MovementAlgorithm,
  Script: Script,
  SetLinguoLevels: SetLinguoLevels,
  setServoCommand: setServoCommand,
  setServoTorque: setServoTorque,
  String: String,
  TTSCommand: TTSCommand,
  TTSWav: TTSWav,
};

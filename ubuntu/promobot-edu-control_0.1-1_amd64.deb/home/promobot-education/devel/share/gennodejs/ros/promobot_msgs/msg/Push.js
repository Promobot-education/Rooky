// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Push {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ico_path = null;
      this.text = null;
      this.timeout = null;
      this.tag = null;
      this.permanent = null;
    }
    else {
      if (initObj.hasOwnProperty('ico_path')) {
        this.ico_path = initObj.ico_path
      }
      else {
        this.ico_path = '';
      }
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('timeout')) {
        this.timeout = initObj.timeout
      }
      else {
        this.timeout = 0;
      }
      if (initObj.hasOwnProperty('tag')) {
        this.tag = initObj.tag
      }
      else {
        this.tag = 0;
      }
      if (initObj.hasOwnProperty('permanent')) {
        this.permanent = initObj.permanent
      }
      else {
        this.permanent = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Push
    // Serialize message field [ico_path]
    bufferOffset = _serializer.string(obj.ico_path, buffer, bufferOffset);
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [timeout]
    bufferOffset = _serializer.int32(obj.timeout, buffer, bufferOffset);
    // Serialize message field [tag]
    bufferOffset = _serializer.int32(obj.tag, buffer, bufferOffset);
    // Serialize message field [permanent]
    bufferOffset = _serializer.bool(obj.permanent, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Push
    let len;
    let data = new Push(null);
    // Deserialize message field [ico_path]
    data.ico_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [timeout]
    data.timeout = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [tag]
    data.tag = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [permanent]
    data.permanent = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.ico_path.length;
    length += object.text.length;
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Push';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '566c3c03da9b78b79bfa91641aa51a4f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string ico_path
    string text
    int32 timeout
    int32 tag
    bool permanent
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Push(null);
    if (msg.ico_path !== undefined) {
      resolved.ico_path = msg.ico_path;
    }
    else {
      resolved.ico_path = ''
    }

    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.timeout !== undefined) {
      resolved.timeout = msg.timeout;
    }
    else {
      resolved.timeout = 0
    }

    if (msg.tag !== undefined) {
      resolved.tag = msg.tag;
    }
    else {
      resolved.tag = 0
    }

    if (msg.permanent !== undefined) {
      resolved.permanent = msg.permanent;
    }
    else {
      resolved.permanent = false
    }

    return resolved;
    }
};

module.exports = Push;

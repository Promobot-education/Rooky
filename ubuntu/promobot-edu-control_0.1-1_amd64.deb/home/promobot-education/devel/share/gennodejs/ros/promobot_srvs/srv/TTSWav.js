// Auto-generated. Do not edit!

// (in-package promobot_srvs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TTSWavRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.text = null;
    }
    else {
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSWavRequest
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSWavRequest
    let len;
    let data = new TTSWavRequest(null);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.text.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/TTSWavRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '74697ed3d931f6eede8bf3a8dfeca160';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string text
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSWavRequest(null);
    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    return resolved;
    }
};

class TTSWavResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.output_path = null;
    }
    else {
      if (initObj.hasOwnProperty('output_path')) {
        this.output_path = initObj.output_path
      }
      else {
        this.output_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSWavResponse
    // Serialize message field [output_path]
    bufferOffset = _serializer.string(obj.output_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSWavResponse
    let len;
    let data = new TTSWavResponse(null);
    // Deserialize message field [output_path]
    data.output_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.output_path.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'promobot_srvs/TTSWavResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7e5fd90f143bb5a54ed92db17c7b0cbe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string output_path
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSWavResponse(null);
    if (msg.output_path !== undefined) {
      resolved.output_path = msg.output_path;
    }
    else {
      resolved.output_path = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TTSWavRequest,
  Response: TTSWavResponse,
  md5sum() { return 'c03eb6e4831b23b8c7ae2f7db703399a'; },
  datatype() { return 'promobot_srvs/TTSWav'; }
};

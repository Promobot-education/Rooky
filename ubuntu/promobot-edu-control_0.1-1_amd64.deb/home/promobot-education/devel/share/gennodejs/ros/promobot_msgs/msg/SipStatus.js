// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SipStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
      this.info = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('info')) {
        this.info = initObj.info
      }
      else {
        this.info = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SipStatus
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [info]
    bufferOffset = _serializer.string(obj.info, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SipStatus
    let len;
    let data = new SipStatus(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [info]
    data.info = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.info.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/SipStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1c44378c3511dbd64ca58abf815c2f8b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 STATUS_IDLE=0
    uint8 STATUS_START=1
    uint8 STATUS_CONNECTING=2
    uint8 STATUS_CONNECTED=3
    uint8 STATUS_FAILED=4
    uint8 STATUS_DISCONNECTED=5
    uint8 STATUS_ICOMING=6
    
    uint8 status
    string info
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SipStatus(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.info !== undefined) {
      resolved.info = msg.info;
    }
    else {
      resolved.info = ''
    }

    return resolved;
    }
};

// Constants for message
SipStatus.Constants = {
  STATUS_IDLE: 0,
  STATUS_START: 1,
  STATUS_CONNECTING: 2,
  STATUS_CONNECTED: 3,
  STATUS_FAILED: 4,
  STATUS_DISCONNECTED: 5,
  STATUS_ICOMING: 6,
}

module.exports = SipStatus;

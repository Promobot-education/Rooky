// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TTSCommand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.text = null;
      this.terminate = null;
      this.uuid = null;
      this.ignore_saving = null;
    }
    else {
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('terminate')) {
        this.terminate = initObj.terminate
      }
      else {
        this.terminate = false;
      }
      if (initObj.hasOwnProperty('uuid')) {
        this.uuid = initObj.uuid
      }
      else {
        this.uuid = '';
      }
      if (initObj.hasOwnProperty('ignore_saving')) {
        this.ignore_saving = initObj.ignore_saving
      }
      else {
        this.ignore_saving = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSCommand
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [terminate]
    bufferOffset = _serializer.bool(obj.terminate, buffer, bufferOffset);
    // Serialize message field [uuid]
    bufferOffset = _serializer.string(obj.uuid, buffer, bufferOffset);
    // Serialize message field [ignore_saving]
    bufferOffset = _serializer.bool(obj.ignore_saving, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSCommand
    let len;
    let data = new TTSCommand(null);
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [terminate]
    data.terminate = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [uuid]
    data.uuid = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [ignore_saving]
    data.ignore_saving = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.text.length;
    length += object.uuid.length;
    return length + 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/TTSCommand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ede3e61dff77ea06df346265266d0074';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string text
    bool terminate
    string uuid
    bool ignore_saving
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSCommand(null);
    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.terminate !== undefined) {
      resolved.terminate = msg.terminate;
    }
    else {
      resolved.terminate = false
    }

    if (msg.uuid !== undefined) {
      resolved.uuid = msg.uuid;
    }
    else {
      resolved.uuid = ''
    }

    if (msg.ignore_saving !== undefined) {
      resolved.ignore_saving = msg.ignore_saving;
    }
    else {
      resolved.ignore_saving = false
    }

    return resolved;
    }
};

module.exports = TTSCommand;

// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Light {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.location = null;
      this.type = null;
      this.time = null;
      this.count = null;
      this.sector = null;
      this.add = null;
      this.R = null;
      this.G = null;
      this.B = null;
    }
    else {
      if (initObj.hasOwnProperty('location')) {
        this.location = initObj.location
      }
      else {
        this.location = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('time')) {
        this.time = initObj.time
      }
      else {
        this.time = 0;
      }
      if (initObj.hasOwnProperty('count')) {
        this.count = initObj.count
      }
      else {
        this.count = 0;
      }
      if (initObj.hasOwnProperty('sector')) {
        this.sector = initObj.sector
      }
      else {
        this.sector = 0;
      }
      if (initObj.hasOwnProperty('add')) {
        this.add = initObj.add
      }
      else {
        this.add = false;
      }
      if (initObj.hasOwnProperty('R')) {
        this.R = initObj.R
      }
      else {
        this.R = 0;
      }
      if (initObj.hasOwnProperty('G')) {
        this.G = initObj.G
      }
      else {
        this.G = 0;
      }
      if (initObj.hasOwnProperty('B')) {
        this.B = initObj.B
      }
      else {
        this.B = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Light
    // Serialize message field [location]
    bufferOffset = _serializer.uint8(obj.location, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [time]
    bufferOffset = _serializer.uint16(obj.time, buffer, bufferOffset);
    // Serialize message field [count]
    bufferOffset = _serializer.uint8(obj.count, buffer, bufferOffset);
    // Serialize message field [sector]
    bufferOffset = _serializer.uint16(obj.sector, buffer, bufferOffset);
    // Serialize message field [add]
    bufferOffset = _serializer.bool(obj.add, buffer, bufferOffset);
    // Serialize message field [R]
    bufferOffset = _serializer.uint8(obj.R, buffer, bufferOffset);
    // Serialize message field [G]
    bufferOffset = _serializer.uint8(obj.G, buffer, bufferOffset);
    // Serialize message field [B]
    bufferOffset = _serializer.uint8(obj.B, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Light
    let len;
    let data = new Light(null);
    // Deserialize message field [location]
    data.location = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [time]
    data.time = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [count]
    data.count = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [sector]
    data.sector = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [add]
    data.add = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [R]
    data.R = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [G]
    data.G = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [B]
    data.B = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 11;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/Light';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '52689a136a7cc77e027ab275e6a11654';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 location
    uint8 ALL       = 0 # Все
    uint8 HEAD      = 1 # Голова
    uint8 SHOLDERS  = 2 # Плечи (V3 only)
    uint8 ELBOW     = 3 # Локти (V3 only)
    
    uint8 type
    uint8 SHARP_BLINK   = 0 # Резкое мигание
    uint8 SHARP_ON      = 1 # Резкое включение
    uint8 SHARP_OFF     = 2 # Резкое выключение
    uint8 SMOOTH_BLINK  = 3 # Плавное мигание
    uint8 SMOOTH_ON     = 4 # Плавное включение
    uint8 SMOOTH_OFF    = 5 # Плавное выключение
    
    # Время одного цикла включения/выключения в миллисекундах
    uint16 time
    
    # Число циклов
    uint8 count
    
    # Маска секторов (V4 only)
    uint16 sector
    
    # Добавить сектор к текущим (V4 only)
    bool add
    
    # Цвета
    uint8 R
    uint8 G
    uint8 B
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Light(null);
    if (msg.location !== undefined) {
      resolved.location = msg.location;
    }
    else {
      resolved.location = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.time !== undefined) {
      resolved.time = msg.time;
    }
    else {
      resolved.time = 0
    }

    if (msg.count !== undefined) {
      resolved.count = msg.count;
    }
    else {
      resolved.count = 0
    }

    if (msg.sector !== undefined) {
      resolved.sector = msg.sector;
    }
    else {
      resolved.sector = 0
    }

    if (msg.add !== undefined) {
      resolved.add = msg.add;
    }
    else {
      resolved.add = false
    }

    if (msg.R !== undefined) {
      resolved.R = msg.R;
    }
    else {
      resolved.R = 0
    }

    if (msg.G !== undefined) {
      resolved.G = msg.G;
    }
    else {
      resolved.G = 0
    }

    if (msg.B !== undefined) {
      resolved.B = msg.B;
    }
    else {
      resolved.B = 0
    }

    return resolved;
    }
};

// Constants for message
Light.Constants = {
  ALL: 0,
  HEAD: 1,
  SHOLDERS: 2,
  ELBOW: 3,
  SHARP_BLINK: 0,
  SHARP_ON: 1,
  SHARP_OFF: 2,
  SMOOTH_BLINK: 3,
  SMOOTH_ON: 4,
  SMOOTH_OFF: 5,
}

module.exports = Light;
